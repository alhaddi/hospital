
<div class="container-fluid">
	<div class="row">
		<div class="col-sm-12">
			<div class="box box-bordered box-color">
				<div class="box-title">
					<h3>
						<i class="fa fa-table"></i>
						Daftar <?=$title?>
					</h3>
					<div class="actions">
						
					</div>
				</div>
				<div class="box-content nopadding">
					
					<table id="<?=$id_table?>" class="table table-hover table-nomargin table-striped table-bordered" 
					data-plugin="datatable-server-side" 
					data-datatable-list="<?=$datatable_list?>"
					data-datatable-delete="<?=$datatable_delete?>"
					data-datatable-colvis="true"
					data-datatable-autorefresh="true"
					data-datatable-daterange="true"
					data-datatable-nocolvis=""
					>
						<thead>
							<tr>
								<th data-datatable-align="text-center" style="width:50px;">No.</th>
								<th data-datatable-align="text-center">RM</th>
								<th data-datatable-align="text-left">Nama Pasien</th>
								<th data-datatable-align="text-center">Cara Bayar</th>
								<th data-datatable-align="text-left">Jenis Bayar</th>
								<th data-datatable-align="text-right">Nominal</th>
								<th data-datatable-align="text-center">Tanggal</th>
								<th data-datatable-align="text-center">Status</th>
								<th data-datatable-align="text-center" style="width:100px;">Action</th>
							</tr>
						</thead>
						<tbody>
							
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>

<?=$load_form?>

<script>
	function modal_pembayaran(id_billing){
		$.ajax({
			url		:"<?=site_url('billing/pembayaran')?>",
			data	:{
				id:id_billing
			},
			type	:"post",
			dataType:"json",
			success	:function(jdata){
				var formz = $('#form_<?=$id_table?>');
				formz[0].reset();
				if(jdata){
					$.each(jdata,function(i,v){
						formz.find('[name="'+i+'"]').val(v);
						formz.find('#'+i).html(v);
					});
				}
				$('#modal_<?=$id_table?>').modal('show');
				$('#modal_<?=$id_table?>').on('shown.bs.modal', function() {
					$(this).find('[name="total_bayar"]').focus();
				});
				formz.find('select').select2();
			}
		});
	}
	
	
		
</script>
