

<?php

defined("BASEPATH") OR exit("No direct script access allowed");



class Rekam_mediss extends MY_Model {



	var $table1;
	var $column_order1;
	var $column_search1;
	var $column_excel1;
	var $column_pdf1;
	var $order1;

	

	public function __construct()

	{

		parent::__construct();

		$this->load->database();

	}

	

	public function initialize($config){

		

		$this->table1 = $config["table1"];

		$this->column_order1 = $config["column_order1"]; //set column field database for datatable orderable

		$this->column_search1 = $config["column_search1"]; //set column field database for datatable searchable just firstname , lastname , address are searchable

		$this->column_excel1 = $config["column_excel1"]; //set column field database for datatable searchable just firstname , lastname , address are searchable

		$this->column_pdf1 = $config["column_pdf1"]; //set column field database for datatable searchable just firstname , lastname , address are searchable

		$this->order1 = $config["order1"]; // default order 

	}

	

	private function _get_datatables_query($p)

	{


		$this->db->from($this->table1); 
		$order = $this->order1;
		$column_excel = $this->column_excel1;
		$column_pdf = $this->column_pdf1;
		$column_search = $this->column_search1;
		$column_order = $this->column_order1;
		
		$i = 0;

	

		foreach ($column_search as $item) // loop column 

		{

			if($_POST["search"]["value"]) // if datatable send POST for search

			{

				

				if($i===0) // first loop

				{

					$this->db->group_start(); // open bracket. query Where with OR clause better with bracket. because maybe can combine with other WHERE with AND.

					$this->db->like($item, $_POST["search"]["value"]);

				}

				else

				{

					$this->db->or_like($item, $_POST["search"]["value"]);

				}



				if(count($column_search) - 1 == $i) //last loop

					$this->db->group_end(); //close bracket

			}

			$i++;

		}

		

		if(isset($_POST["order"])) // here order processing

		{

			$this->db->order_by($this->column_order[$_POST["order"]["0"]["column"]], $_POST["order"]["0"]["dir"]);

		} 

		else if(isset($order))

		{

			$this->db->order_by(key($order), $order[key($order)]);

		}

	}



	function get_datatables($p)

	{

		$this->_get_datatables_query($p);
		
		$date_filter = array(
			1=>'ms_pasien',
			2=>'trs_appointment',
			3=>'trs_billing'
		);
		
		
		if(!empty($_POST['custom_filter']) && !empty($date_filter[$p]))
		{
			$custom_filter = $_POST['custom_filter'];
			
			if(count($custom_filter)>0)
			{
				foreach($custom_filter as $cf){
					foreach($cf  as $index=>$value){
						if($index == 'datatable_daterange1')
						{
							$date1 = $value;
						}
						elseif($index == 'datatable_daterange2')
						{
							$date2 = $value;
						}
						else
						{
							$where_filter[$index] = $value;
						}
					}
					
					if(!empty($date1) && !empty($date2))
					{
						$this->db->where('DATE('.$date_filter[$p].'.add_time) >=',convert_tgl($date1,'Y-m-d'));
						$this->db->where('DATE('.$date_filter[$p].'.add_time) <=',convert_tgl($date2,'Y-m-d'));
					}
				}
				if(!empty($where_filter))
				{
					$where_filter = array_filter($where_filter);
					$this->db->group_start(); // open bracket. query Where with OR clause better with bracket. because maybe can combine with other WHERE with AND.
						$this->db->where($where_filter);
					$this->db->group_end(); //close bracket
				}
			}
		}
		
		if($_POST["length"] != -1)

		{

			$this->db->limit($_POST["length"], $_POST["start"]);

		}

		$query = $this->db->get();
		

		return $query->result();

	}



	function count_filtered($p)

	{

		$this->_get_datatables_query($p);

		$query = $this->db->select('ms_poliklinik.id')->get();

		return $query->num_rows();

	}



	public function count_all($p)

	{

		$this->db->from($this->table1);

		return $this->db->count_all_results();

	}

	

	public function get_kategori($id){

		$this->db->select('a.id')

		->join('trs_appointment as b','b.id_pasien = a.id')

		->join('ms_cara_bayar as c','b.id_cara_bayar = c.id')

		->where('a.status','billing')

		->where('b.id_poliklinik',$id);

	}

	

	public function get_pekerjaan(){

		$this->db->join('ms_pekerjaan as d','a.id_pekerjaan = d.id')

		->where('d.nama','RSU');

	}

	

	public function get_umum($id){

		$this->get_kategori($id);

		$this->db->where('c.nama','UMUM')

		->where('month(a.add_time) BETWEEN month(NOW())-1 AND month(NOW())')

		->get('ms_pasien as a');

		return $this->db -> count_all_results();

	}

	

	public function get_kontrak($id){

		$this->get_kategori($id);

		$this->db->where('c.nama','KONRAKTOR')

		->where('month(a.add_time) BETWEEN month(NOW())-1 AND month(NOW())')

		->get('ms_pasien as a');

		return $this->db->count_all_results();

	}

	

	public function get_rsu(){

		$this->get_pekerjaan();

		$this->db->select('a.id')

		->where('a.status','billing')

		->where('month(a.add_time) BETWEEN month(NOW())-1 AND month(NOW())')

		->get('ms_pasien as a');

		return $this->db->count_all_results();

	}

	

	public function get_kategori_baru($id){

		$this->get_kategori($id);

		$this->get_pekerjaan();

		$this->db->where('month(a.add_time)', date('m'))

		->where('c.nama','UMUM')

		->or_where('c.nama','KONRAKTOR')

		->get('ms_pasien as a');

		return $this->db->count_all_results();

	}

	

	public function get_kategori_lama($id){

		$this->get_kategori($id);

		$this->get_pekerjaan();

		$this->db->where('month(a.add_time)', (date('m')-1))

		->where('c.nama','UMUM')

		->or_where('c.nama','KONRAKTOR')

		->get('ms_pasien as a');

		return $this->db->count_all_results();

	}

	

	public function get_pembayaran($id){

		$this->db->select('a.id')

		->join('trs_appointment as b','b.id_pasien = a.id')

		->join('ms_cara_bayar as c','b.id_cara_bayar = c.id')

		->join('ms_bpjs_type as d','b.id_bpjs_type = d.id')

		->where('d.nama','BPJS')

		->where('a.status','billing')

		->where('b.id_poliklinik',$id);

	}

	

	public function get_akses($id){

		$this->get_pembayaran($id);

		$this->db->where('d.nama', 'AKSES')

		->where('month(a.add_time) between month(NOW())-1 AND month(NOW())')

		->get('ms_pasien as a');

		return $this->db->count_all_results();

	}

	

	public function get_kis($id){

		$this->get_pembayaran($id);

		$this->db->where('d.nama', 'KIS')

		->where('month(a.add_time) between month(NOW())-1 AND month(NOW())')

		->get('ms_pasien as a');

		return $this->db->count_all_results();

	}

	

	public function get_jmsstk($id){

		$this->get_pembayaran($id);

		$this->db->where('d.nama', 'JMSSTK')

		->where('month(a.add_time) BETWEEN month(NOW())-1 AND month(NOW())')

		->get('ms_pasien as a');

		return $this->db->count_all_results();

	}

	

	public function get_tni($id){

		$this->get_pembayaran($id);

		$this->db->where('d.nama', 'TNI')

		->where('month(a.add_time) BETWEEN month(NOW())-1 AND month(NOW())')

		->get('ms_pasien as a');

		return $this->db->count_all_results();

	}

	

	public function get_mandiri($id){

		$this->get_pembayaran($id);

		$this->db->where('d.nama', 'MANDIRI')

		->where('month(a.add_time) BETWEEN month(NOW())-1 AND month(NOW())')

		->get('ms_pasien as a');

		return $this->db->count_all_results();

	}

	

	public function get_pembayaran_baru($id){

		$this->get_pembayaran($id);

		$this->db->where('month(a.add_time)', date('m'))

		->get('ms_pasien as a'); 

		return $this->db->count_all_results();

	}

	

	public function get_pembayaran_lama($id){

		$this->get_pembayaran($id);

		$this->db->where('month(a.add_time)', (date('m')-1))

		->get('ms_pasien as a');

		return $this->db->count_all_results();

	}
	

	public function list_fields($list_fields){

		$this->db->select(implode(",",$list_fields));

		$this->db->limit(1,0);

		

		$query = $this->db->get($this->table1);

		return $query->field_data();

	}

	

	public function data_excel($field="",$p){

		$this->db->from($this->table1); 

		$column_excel = $this->column_excel1;

		$field = (!empty($field))?$field:$column_excel;

		$query = $this->db->get();

		return $query->result_array();

	}

	

	public function data_pdf($p){

		$this->db->from($this->table1); 

		$column_pdf = $this->column_pdf4;

		$field = (!empty($field))?$field:$column_pdf;

		$query = $this->db->get();

		return $query->result_array();

	}

	

}



