<?php



/**

     * APLICATION INFO  : PDF Report with FPDF 1.6

     * DATE CREATED     : 21 juni 2013

   * DEVELOPED BY     : Radi Ganteng 

   */



/* setting zona waktu */ 

//date_default_timezone_set('Asia/Jakarta');



/* konstruktor halaman pdf sbb :    

   P  = Orientasinya "Potrait"

   cm = ukuran halaman dalam satuan centimeter

   A4 = Format Halaman

   

   jika ingin mensetting sendiri format halamannya, gunakan array(width, height)  

   contoh : $this->fpdf->FPDF("P","cm", array(20, 20));  

*/



$this->fpdf = new fpdf();



//$this->fpdf->FPDF("P","cm","Legal");

$this->fpdf->FPDF('L','cm',"A4");



// kita set marginnya dimulai dari kiri, atas, kanan. jika tidak diset, defaultnya 1 cm

$this->fpdf->SetMargins(0,0.5,0.5,0);

$this->fpdf->SetAutoPageBreak(false);



/* AliasNbPages() merupakan fungsi untuk menampilkan total halaman

   di footer, nanti kita akan membuat page number dengan format : number page / total page

*/

$this->fpdf->AliasNbPages();



// AddPage merupakan fungsi untuk membuat halaman baru

$this->fpdf->AddPage();



$this->fpdf->SetFont('Arial','',8); 

$this->fpdf->setXY(0.5,3);

$this->fpdf->Cell(5.5,2,'HARI/TANGGAL : ',0,0,'C');



$namahari = date('l');

$namabulan = date('n');

  

  if ($namahari == "Sunday") $namahari2 = "Minggu"; 

  else if ($namahari == "Monday") $namahari2 = "Senin"; 

  else if ($namahari == "Tuesday") $namahari2 = "Selasa"; 

  else if ($namahari == "Wednesday") $namahari2 = "Rabu"; 

  else if ($namahari == "Thursday") $namahari2 = "Kamis"; 

  else if ($namahari == "Friday") $namahari2 = "Jumat"; 

  else if ($namahari == "Saturday") $namahari2 = "Sabtu";



  switch ($namabulan) {

    case '1':

    $namabulan2 = "Januari";

    break;

    case '2':

    $namabulan2 = "Februari";

    break;

    case '3':

    $namabulan2 = "Maret";

    break;

    case '4':

    $namabulan2 = "April";

    break;

    case '5':

    $namabulan2 = "Mei";

    break;

    case '6':

    $namabulan2 = "Juni";

    break;

    case '7':

    $namabulan2 = "Juli";

    break;

    case '8':

    $namabulan2 = "Agustus";

    break;

    case '9':

    $namabulan2 = "September";

    break;

    case '10':

    $namabulan2 = "Oktober";

    break;

    case '11':

    $namabulan2 = "November";

    break;

    case '12':

    $namabulan2 = "Desember";

    break;

    

    default:

      break;

  }



$this->fpdf->SetFont('Arial','',8); 

$this->fpdf->setXY(3.7,3);

$this->fpdf->Cell(5.5,2,$namahari2.', '.date('d').' '.$namabulan2.' '.date('Y'),0,0,'C');



$this->fpdf->SetFont('Arial','B',8); 

$this->fpdf->setXY(0.7,4.5);



$this->fpdf->Cell(0.5,1.4,'NO',1,0,'C');

$this->fpdf->Cell(12.5,0.7,'KATEGORI',1,0,'C');

$this->fpdf->Cell(11,0.7,'PEMBAYARAN',1,0,'C');

$this->fpdf->Cell(1.5,1.4,'TTL BARU',1,0,'C');

$this->fpdf->Cell(1.5,1.4,'TTL LAMA',1,0,'C');

$this->fpdf->Cell(1.5,1.4,'TOTAL',1,0,'C');



$this->fpdf->setXY(1.2,5.2);

$this->fpdf->Cell(3.5,0.7,'KLINIK',1,0,'C');

$this->fpdf->Cell(1.5,0.7,'UMUM',1,0,'C');

$this->fpdf->Cell(2,0.7,'KONTRAK',1,0,'C');

$this->fpdf->Cell(1,0.7,'RSU',1,0,'C');

$this->fpdf->Cell(1.5,0.7,'BARU',1,0,'C');

$this->fpdf->Cell(1.5,0.7,'LAMA',1,0,'C');

$this->fpdf->Cell(1.5,0.7,'JML',1,0,'C');



$this->fpdf->Cell(1.5,0.7,'AKSES',1,0,'C');

$this->fpdf->Cell(1,0.7,'KIS',1,0,'C');

$this->fpdf->Cell(1.5,0.7,'JMSSTK',1,0,'C');

$this->fpdf->Cell(1,0.7,'TNI',1,0,'C');

$this->fpdf->Cell(1.5,0.7,'MANDIRI',1,0,'C');

$this->fpdf->Cell(1.5,0.7,'BARU',1,0,'C');

$this->fpdf->Cell(1.5,0.7,'LAMA',1,0,'C');

$this->fpdf->Cell(1.5,0.7,'JML',1,0,'C');



$x = 0;

$y = 5.9;

$jmlkate = 0; 

$jmlbayar = 0;

$ttllama = 0;

$ttlbaru = 0;



foreach ($polikliniks as $pl) :



  if(($x+1) % 21 == 0){



    $this->fpdf->AddPage();



    $this->fpdf->SetFont('Arial','',8); 

    $this->fpdf->setXY(0.5,3);

    $this->fpdf->Cell(5.5,2,'HARI/TANGGAL : ',0,0,'C');



    $this->fpdf->setXY(3.7,3);

    $this->fpdf->Cell(5.5,2,$namahari2.', '.date('d').' '.$namabulan2.' '.date('Y'),0,0,'C');



    $this->fpdf->setXY(3.7,3);

    $this->fpdf->Cell(5.5,2,$namahari2.', '.date('d').' '.$namabulan2.' '.date('Y'),0,0,'C');



    $this->fpdf->SetFont('Arial','B',8); 

    $this->fpdf->setXY(0.7,4.5);



    $this->fpdf->Cell(0.5,1.4,'NO',1,0,'C');

    $this->fpdf->Cell(12.5,0.7,'KATEGORI',1,0,'C');

    $this->fpdf->Cell(11,0.7,'PEMBAYARAN',1,0,'C');

    $this->fpdf->Cell(1.5,1.4,'TTL BARU',1,0,'C');

    $this->fpdf->Cell(1.5,1.4,'TTL LAMA',1,0,'C');

    $this->fpdf->Cell(1.5,1.4,'TOTAL',1,0,'C');



    $this->fpdf->setXY(1.2,5.2);

    $this->fpdf->Cell(3.5,0.7,'KLINIK',1,0,'C');

    $this->fpdf->Cell(1.5,0.7,'UMUM',1,0,'C');

    $this->fpdf->Cell(2,0.7,'KONTRAK',1,0,'C');

    $this->fpdf->Cell(1,0.7,'RSU',1,0,'C');

    $this->fpdf->Cell(1.5,0.7,'BARU',1,0,'C');

    $this->fpdf->Cell(1.5,0.7,'LAMA',1,0,'C');

    $this->fpdf->Cell(1.5,0.7,'JML',1,0,'C');



    $this->fpdf->Cell(1.5,0.7,'AKSES',1,0,'C');

    $this->fpdf->Cell(1,0.7,'KIS',1,0,'C');

    $this->fpdf->Cell(1.5,0.7,'JMSSTK',1,0,'C');

    $this->fpdf->Cell(1,0.7,'TNI',1,0,'C');

    $this->fpdf->Cell(1.5,0.7,'MANDIRI',1,0,'C');

    $this->fpdf->Cell(1.5,0.7,'BARU',1,0,'C');

    $this->fpdf->Cell(1.5,0.7,'LAMA',1,0,'C');

    $this->fpdf->Cell(1.5,0.7,'JML',1,0,'C');

  }



  $this->fpdf->SetFont('Arial','',8); 

  $this->fpdf->setXY(0.7,$y+($x*0.7));

  $this->fpdf->Cell(0.5,0.7,$pl['id'],1,0,'C');

  $this->fpdf->Cell(3.5,0.7,$pl['nama'],1,0,'C');



	$this->db->select('count(a.id) as jml');

	$this->db->join('trs_appointment as b','b.id_pasien = a.id');

	$this->db->join('ms_cara_bayar as c','b.id_cara_bayar = c.id');

	$this->db->where('a.status','billing');

	$this->db->where('c.nama','UMUM');

	$this->db->where('b.id_poliklinik',$pl['id']);

	$this->db->where('month(a.add_time) BETWEEN month(NOW())-1 AND month(NOW())');

	$pasien = $this->db->get('ms_pasien as a') -> row_array();



  $jmlkate += $pasien['jml'];



  $this->fpdf->Cell(1.5,0.7,$pasien['jml'],1,0,'C');



	$this->db->select('count(a.id) as jml');

	$this->db->join('trs_appointment as b','b.id_pasien = a.id');

	$this->db->join('ms_cara_bayar as c','b.id_cara_bayar = c.id');

	$this->db->where('a.status','billing');

	$this->db->where('c.nama','KONRAKTOR');

	$this->db->where('b.id_poliklinik',$pl['id']);

	$this->db->where('month(a.add_time) BETWEEN month(NOW())-1 AND month(NOW())');

	$pasien = $this->db->get('ms_pasien as a') -> row_array();



  $jmlkate += $pasien['jml'];



  $this->fpdf->Cell(2,0.7,$pasien['jml'],1,0,'C');



	$this->db->select('count(a.id) as jml');

	$this->db->join('ms_pekerjaan as b','a.id_pekerjaan = b.id');

	$this->db->where('a.status','billing');

	$this->db->where('b.nama','RSU');

	$this->db->where('month(a.add_time) BETWEEN month(NOW())-1 AND month(NOW())');

	$pasien = $this->db->get('ms_pasien as a') -> row_array();



  $jmlkate += $pasien['jml'];



  $this->fpdf->Cell(1,0.7,$pasien['jml'],1,0,'C');



	$this->db->select('count(a.id) as jml');

	$this->db->join('trs_appointment as b','b.id_pasien = a.id');

	$this->db->join('ms_pekerjaan as c','a.id_pekerjaan = c.id');

	$this->db->join('ms_cara_bayar as d','b.id_cara_bayar = d.id');

	$this->db->where('a.status','billing');

	$this->db->where('b.id_poliklinik',$pl['id']);

	$this->db->where('month(a.add_time)', date('m'));

	$this->db->where('d.nama','UMUM');

	$this->db->or_where('d.nama','KONRAKTOR');

	$this->db->or_where('c.nama','RSU');

	$pasien = $this->db->get('ms_pasien as a') -> row_array();



  $jmlkate += $pasien['jml'];

  $ttlbaru += $pasien['jml'];



  $this->fpdf->Cell(1.5,0.7,$pasien['jml'],1,0,'C');



	$this->db->select('count(a.id) as jml');

	$this->db->join('trs_appointment as b','b.id_pasien = a.id');

	$this->db->join('ms_pekerjaan as c','a.id_pekerjaan = c.id');

	$this->db->join('ms_cara_bayar as d','b.id_cara_bayar = d.id');

	$this->db->where('a.status','billing');

	$this->db->where('b.id_poliklinik',$pl['id']);

	$this->db->where('month(a.add_time)', (date('m')-1));

	$this->db->where('d.nama','UMUM');

	$this->db->or_where('d.nama','KONRAKTOR');

	$this->db->or_where('c.nama','RSU');

	$pasien = $this->db->get('ms_pasien as a') -> row_array();



  $jmlkate += $pasien['jml'];

  $ttllama += $pasien['jml'];



  $this->fpdf->Cell(1.5,0.7,$pasien['jml'],1,0,'C');



  $this->fpdf->Cell(1.5,0.7,$jmlkate,1,0,'C');





	$this->db->select('count(a.id) as jml');

	$this->db->join('trs_appointment as b','b.id_pasien = a.id');

	$this->db->join('ms_cara_bayar as c','b.id_cara_bayar = c.id');

	$this->db->join('ms_bpjs_type as d','b.id_bpjs_type = d.id');

	$this->db->where('d.nama','BPJS');

	$this->db->where('a.status','billing');

	$this->db->where('d.nama', 'AKSES');

	$this->db->where('b.id_poliklinik',$pl['id']);

	$this->db->where('month(a.add_time) between month(NOW())-1 AND month(NOW())');

	$bayar = $this->db->get('ms_pasien as a') -> row_array();



  $jmlbayar += $bayar['jml'];



  $this->fpdf->Cell(1.5,0.7,$bayar['jml'],1,0,'C');



	$this->db->select('count(a.id) as jml');

	$this->db->join('trs_appointment as b','b.id_pasien = a.id');

	$this->db->join('ms_cara_bayar as c','b.id_cara_bayar = c.id');

	$this->db->join('ms_bpjs_type as d','b.id_bpjs_type = d.id');

	$this->db->where('d.nama','BPJS');

	$this->db->where('a.status','billing');

	$this->db->where('d.nama', 'KIS');

	$this->db->where('b.id_poliklinik',$pl['id']);

	$this->db->where('month(a.add_time) between month(NOW())-1 AND month(NOW())');

	$bayar = $this->db->get('ms_pasien as a') -> row_array();



  $jmlbayar += $bayar['jml'];



  $this->fpdf->Cell(1,0.7,$bayar['jml'],1,0,'C');



	$this->db->select('count(a.id) as jml');

	$this->db->join('trs_appointment as b','b.id_pasien = a.id');

	$this->db->join('ms_cara_bayar as c','b.id_cara_bayar = c.id');

	$this->db->join('ms_bpjs_type as d','b.id_bpjs_type = d.id');

	$this->db->where('d.nama','BPJS');

	$this->db->where('a.status','billing');

	$this->db->where('d.nama', 'JMSSTK');

	$this->db->where('b.id_poliklinik',$pl['id']);

	$this->db->where('month(a.add_time) BETWEEN month(NOW())-1 AND month(NOW())');

	$bayar = $this->db->get('ms_pasien as a') -> row_array();



  $jmlbayar += $bayar['jml'];



  $this->fpdf->Cell(1.5,0.7,$bayar['jml'],1,0,'C');



	$this->db->select('count(a.id) as jml');

	$this->db->join('trs_appointment as b','b.id_pasien = a.id');

	$this->db->join('ms_cara_bayar as c','b.id_cara_bayar = c.id');

	$this->db->join('ms_bpjs_type as d','b.id_bpjs_type = d.id');

	$this->db->where('d.nama','BPJS');

	$this->db->where('a.status','billing');

	$this->db->where('d.nama', 'TNI');

	$this->db->where('b.id_poliklinik',$pl['id']);

	$this->db->where('month(a.add_time) BETWEEN month(NOW())-1 AND month(NOW())');

	$bayar = $this->db->get('ms_pasien as a') -> row_array();



  $jmlbayar += $bayar['jml'];



  $this->fpdf->Cell(1,0.7,$bayar['jml'],1,0,'C');



  $this->db->select('count(a.id) as jml');

  $this->db->join('trs_appointment as b','b.id_pasien = a.id');

  $this->db->join('ms_bpjs_type as d','b.id_bpjs_type = d.id');

  $this->db->join('ms_cara_bayar as c','b.id_cara_bayar = c.id');

  $this->db->where('d.nama','BPJS');

  $this->db->where('a.status','billing');

  $this->db->where('d.nama', 'MANDIRI');

  $this->db->where('MONTH(a.add_time) BETWEEN MONTH(NOW())-1 AND MONTH(NOW())');

  $bayar = $this->db->get('ms_pasien as a') -> row_array();



  $jmlbayar += $bayar['jml'];



  $this->fpdf->Cell(1.5,0.7,$bayar['jml'],1,0,'C');



	$this->db->select('count(a.id) as jml');

	$this->db->join('trs_appointment as b','b.id_pasien = a.id');

	$this->db->join('ms_cara_bayar as c','b.id_cara_bayar = c.id');

	$this->db->where('a.status','billing');

	$this->db->where('b.id_poliklinik',$pl['id']);

	$this->db->where('month(a.add_time)', date('m'));

	$bayar = $this->db->get('ms_pasien as a') -> row_array();



  $jmlbayar += $bayar['jml'];



  $this->fpdf->Cell(1.5,0.7,$bayar['jml'],1,0,'C');



	$this->db->select('count(a.id) as jml');

	$this->db->join('trs_appointment as b','b.id_pasien = a.id');

	$this->db->join('ms_cara_bayar as c','b.id_cara_bayar = c.id');

	$this->db->where('a.status','billing');

	$this->db->where('b.id_poliklinik',$pl['id']);

	$this->db->where('month(a.add_time)', (date('m')-1));

	$bayar = $this->db->get('ms_pasien as a') -> row_array();



  $jmlbayar += $bayar['jml'];



  $this->fpdf->Cell(1.5,0.7,$bayar['jml'],1,0,'C');



  $this->fpdf->Cell(1.5,0.7,$jmlbayar,1,0,'C');



  $this->fpdf->Cell(1.5,0.7,$ttllama,1,0,'C');



  $this->fpdf->Cell(1.5,0.7,$ttlbaru,1,0,'C');



  $this->fpdf->Cell(1.5,0.7,($jmlkate+$jmlbayar),1,0,'C');



  $x++;

endforeach;



  $this->fpdf->setXY(3.5,$y+1+($x*0.7));

  $this->fpdf->Cell(1,1,'NO.STROOK KELUAR : 100-112',0,0,'C');



  $this->fpdf->setXY(0.7,$y+2+($x*0.7));

  $this->fpdf->Cell(10,2,'',1,0,'C');

  $this->fpdf->Cell(18.5,2,'Garut,...............................................................',1,0,'C');



  $this->fpdf->setXY(7,$y+2.5+($x*0.7));

  $this->fpdf->Cell(25.5,2,'Petugas',0,0,'C');



    $this->fpdf->Output("kunjungan_pasien.pdf","I");


?>

