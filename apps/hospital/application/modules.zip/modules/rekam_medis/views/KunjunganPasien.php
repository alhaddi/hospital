
            <button onclick="location.href='<?=site_url('report/excel/1')?>'" class="btn btn-xs btn-success"><span class="fa fa-file"></span> &nbsp; Excel File </button>

            <button onclick="location.href='<?=site_url('report/showKunjungan')?>'" class="btn btn-xs btn-success"><span class="fa fa-print"></span> &nbsp; Pdf File </button>
<table id="<?=$id_table1?>" class="table table-hover table-nomargin table-striped table-bordered" 

data-plugin="datatable-server-side" 

data-datatable-list="<?=$datatable_list1?>"

data-datatable-colvis="true"
data-datatable-scroller="true"
data-datatable-scroll-x="true"


data-datatable-nocolvis=""

>

	<thead>


    <tr>

        <th data-datatable-align="text-center" rowspan="2" style="vertical-align: middle" width="50">No</th>

        <th data-datatable-align="text-center" colspan="7">Kategori</th>

        <th data-datatable-align="text-center" colspan="8">Pembayaran</th>

        <th data-datatable-align="text-center" rowspan="2" style="vertical-align: middle">TTL Baru</th>

        <th data-datatable-align="text-center" rowspan="2" style="vertical-align: middle">TTL Lama</th>

        <th data-datatable-align="text-center" rowspan="2" style="vertical-align: middle">Total</th>

    </tr>

    <tr>



        <th>Klinik</th>

        <th>Umum</th>

        <th>Kontrak</th>

        <th>RSU</th>

        <th>Baru</th>

        <th>Lama</th>

        <th>JML</th>



        <th>Askes</th>

        <th>KIS</th>

        <th>JMSSTK</th>

        <th>TNI</th>

        <th>Mandiri</th>

        <th>Baru</th>

        <th>Lama</th>

        <th>JML</th>



    </tr>

    </thead>

	<tbody>

		

	</tbody>

</table>