<?php
	/**
		* CodeIgniter Core Model
		*
		* @package         CodeIgniter
		* @subpackage      Controller
		* @category        Pasien Controller
		* @author          Amir Mufid
		* @version         1.1
	*/defined('BASEPATH') OR exit('No direct script access allowed');
	class Rekam_medis extends MY_Controller{
		
		function __construct()    {
			parent::__construct();
			$this->load->library("fpdf");
			$this->load->model('Rekam_mediss');
			$config['table1'] = 'ms_poliklinik';
			$config['column_order1'] = array('ms_poliklinik.id','ms_poliklinik.nama',null);
			$config['column_search1'] = array('ms_poliklinik.id','ms_poliklinik.nama');
			$config['column_excel1'] = array('ms_poliklinik.id','ms_poliklinik.nama',null);
			$config['column_pdf1'] = array('ms_poliklinik.id','ms_poliklinik.nama',null);
			$config['order1'] = array('ms_poliklinik.id' => 'ASC');
			$this->Rekam_mediss->initialize($config);
		}
		
		public
		function index()    {
			$data['data']['title'] = 'Mis Report';
			$data['data']['id_table1'] = 'kunjungan_konsultasi';
			$data['data']['datatable_list1'] = 'rekam_medis/ajax_list1';
			$this->template->display('dashboard',$data);
		}
		
		public
		function ajax_list1(){
			$list = $this->Rekam_mediss->get_datatables('6');
			$jml_kate = 0;
			$jml_bayar = 0;
			$ttl_baru = 0;
			$ttl_lama = 0;
			$total = 0;
			$data = array();
			$no = $_POST['start'];
			foreach ($list as $row) {
				$no++;
				$fields = array();
				$fields[] = $no;
				$fields[] = $row->nama;
				$umum = $this->Rekam_mediss->get_umum($row->id);
				$fields[] = (isset($umum) || $umum!='')?$umum:'0';
				$kontrak = $this->Rekam_mediss->get_kontrak($row->id);
				$fields[] = (isset($kontrak) || $kontrak!='')?$kontrak:'0';
				$rsu = $this->Rekam_mediss->get_rsu($row->id);
				$fields[] = (isset($rsu) || $rsu!='')?$rsu:'0';
				$kate_baru = $this->Rekam_mediss->get_kategori_baru($row->id);
				$fields[] = (isset($kate_baru) || $kate_baru!='')?$kate_baru:'0';
				$kate_lama = $this->Rekam_mediss->get_kategori_lama($row->id);
				$fields[] = (isset($kate_lama) || $kate_baru!='')?$kate_lama:'0';
				$jml_kate = $umum+$kontrak+$rsu;
				$fields[] = $jml_kate;
				$akses = $this->Rekam_mediss->get_akses($row->id);
				$fields[] = (isset($akses) || $akses!='')?$akses:'0';
				$kis = $this->Rekam_mediss->get_kis($row->id);
				$fields[] = (isset($kis) || $kis!='')?$kis:'0';
				$jmsstk = $this->Rekam_mediss->get_jmsstk($row->id);
				$fields[] = (isset($jmsstk) || $jmsstk!='')?$jmsstk:'0';
				$tni = $this->Rekam_mediss->get_tni($row->id);
				$fields[] = (isset($tni) || $tni!='')?$tni:'0';
				$mandiri = $this->Rekam_mediss->get_mandiri($row->id);
				$fields[] = (isset($mandiri) || $mandiri!='')?$mandiri:'0';
				$bayar_baru = $this->Rekam_mediss->get_pembayaran_baru($row->id);
				$fields[] = (isset($bayar_baru) || $bayar_baru!='')?$bayar_baru:'0';
				$bayar_lama = $this->Rekam_mediss->get_pembayaran_lama($row->id);
				$fields[] = (isset($bayar_lama) || $bayar_lama!='')?$bayar_lama:'0';
				$jml_bayar = $akses+$kis+$jmsstk+$tni+$mandiri;
				$fields[] = $jml_bayar;
				$ttl_baru = $kate_baru+$bayar_baru;
				$fields[] = $ttl_baru;
				$ttl_lama = $kate_lama+$kate_lama;
				$fields[] = $ttl_lama;
				$total = $jml_kate+$jml_bayar;
				$fields[] = $total;
				$data[] = $fields;
			}
			
			$output = array("draw" => $_POST['draw'],"recordsTotal" => $this->Rekam_mediss->count_all('6'),"recordsFiltered" => $this->Rekam_mediss->count_filtered('6'),"data" => $data,);
			echo json_encode($output);		
		}
		
		public
		function excel($p){
			$this->load->library("Excel");
			$query = $this->Rekam_mediss->data_excel('',$p);
			
			$this->excel->export($query);
		}
		
		public
		function showKunjungan()    {
			$data['polikliniks'] = $this->Rekam_mediss->data_pdf('');
			$this->load->view('kunjungan_pasien_report',$data);
		}		
	}
	
?>