
<form id="form_<?=$id_table?>" action="<?=site_url($datatable_save)?>" method="POST">
	<div id="modal_<?=$id_table?>" class="modal fade in" role="dialog">
		<div class="modal-dialog" style="width:80%;">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
					<h4 class="modal-title" id="myModalLabel"><span id="modal_title"></span> <?=$title?></h4>
				</div>
				<!-- /.modal-header -->
				<div class="modal-body">
					<div class="form-horizontal">
						<input type="hidden" name="id" id="id">
						<div class="row">
							<div class="col-sm-6">
								<?php 
									$split = ceil(count($komponen_anamesa)/2);
									$x=0;
									foreach($komponen_anamesa as $komponen) { ?>
									
									
									<?php if($x==$split) { echo '</div><div class="col-sm-6">';  }?>
									<div class="form-group">
										<label for="komponen_<?=element('id',$komponen)?>" class="control-label col-sm-4"><?=element('nama',$komponen)?></label>
										<div class="col-sm-4">
											<div class="input-group">
												<input type="text" name="komponen[<?=element('id',$komponen)?>]" id="komponen_<?=element('id',$komponen)?>" class="form-control" data-rule-number="true" >
												<span class="input-group-addon">
													<?=element('satuan',$komponen)?>
												</span>
											</div>
											
										</div>
									</div>
								<?php $x++;} ?>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-12">
								<div class="form-group">
									<label for="keterangan" class="control-label col-sm-2">Keterangan</small></label>
									<div class="col-sm-8">
										<textarea name="keterangan" id="keterangan" class="form-control"> </textarea>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!-- /.modal-body -->
				<div class="modal-footer">
					<button type="submit" class="btn btn-primary"><i class="fa fa-save fa-fw"></i> Simpan</button>
					<button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
				</div>
				<!-- /.modal-footer -->
			</div>
			<!-- /.modal-content -->
		</div>
		<!-- /.modal-dialog -->
	</div>
</form>

