
<form data-datatable-action="save" data-datatable-idtable="<?=$id_table?>" id="form_<?=$id_table?>" action="<?=site_url($datatable_save)?>" method="POST">
	<div data-datatable-idtable="<?=$id_table?>" class="modal fade in" role="dialog">
		<div class="modal-dialog" style="width: 80%">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
					<h4 class="modal-title" id="myModalLabel"><span id="modal_title"></span> <?=$title?></h4>
				</div>
				<!-- /.modal-header -->
				<div class="modal-body">
					<div class="form-horizontal">
						<input type="hidden" name="id" id="id">
						
						<div class="row">
							<div class="col-sm-6">

								<div class="form-group">
									<label for="id_anggaran" class="control-label col-sm-4">Jenis Biaya</label>
									<div class="col-sm-6">
										<select name='id_anggaran' class="form-control" id='id_anggaran'>
										<option value="">-- Pilih Anggaran --</option>
										<?php foreach($anggaran as $r){?>
											<option value="<?=$r['id']?>"><?=$r['no_rekening']." - ".$r['nama_anggaran']?></option>
										<?php } ?>
										</select>
									</div>
								</div>
								
								<div class="form-group">
									<label for="no_cek" class="control-label col-sm-4">No.Cek</label>
									<div class="col-sm-6">
										<input type="text" name="no_cek" id="no_cek" class="form-control" data-rule-required="true">
									</div>
								</div>
								
								<div class="form-group">
									<label for="no_cek" class="control-label col-sm-4">Tanggal</label>
									<div class="col-sm-6">
										<input type="text" name="tgl_blud" id="tgl_blud" class="form-control" data-rule-required="true" data-plugin="datepicker">
									</div>
								</div>
								
								<div class="form-group">
									<label for="jumlah" class="control-label col-sm-4">Jumlah</label>
									<div class="col-sm-6">
										<input type="text" name="jumlah" id="jumlah" class="form-control" data-plugin="maskmoney" data-rule-required="true">
									</div>
								</div>
							</div>
							<div class="col-sm-6">		
								<div class="form-group">
									<label for="ppn" class="control-label col-sm-4">PPn</label>
									<div class="col-sm-6">
										<input type="text" name="ppn" id="ppn" class="form-control" data-plugin="maskmoney">
									</div>
								</div>
								
								<div class="form-group">
									<label for="id_kategori_pph" class="control-label col-sm-4">Kategori PPh</label>
									<div class="col-sm-6">
										<select name='id_kategori_pph' class="form-control" id='id_kategori_pph'>
										<option value="">-- Pilih Kategori PPh--</option>
										<?php foreach($kategori_pph as $r){?>
											<option value="<?=$r['id']?>"><?=$r['nama_pph']?></option>
										<?php } ?>
										</select>
									</div>
								</div>
								
								<div class="form-group">
									<label for="pph" class="control-label col-sm-4">PPh</label>
									<div class="col-sm-6">
										<input type="text" name="pph" id="pph" class="form-control" data-plugin="maskmoney">
									</div>
								</div>
								
								<div class="form-group">
									<label for="setoran" class="control-label col-sm-4">Kategori Belanja</label>
									<div class="col-sm-2">
										<input type="checkbox" name="ls" id="ls" value="LS" <?=(isset($ls))?'checked':''?>> LS
									</div>
									<div class="col-sm-2">
										<input type="radio" name="gu" id="gu" value="GU" <?=(isset($gu) && $gu == 'GU')?'checked':''?>> GU 
									</div>
									<div class="col-sm-2">
										<input type="radio" name="gu" id="tup" value="TUP" <?=(isset($gu) && $gu == 'TUP')?'checked':''?>> TUP
									</div>								
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-sm-12">
									<label for="uraian" class="control-label">Uraian</label>
									<textarea name="uraian" id="uraian" class="form-control" data-rule-required="true"></textarea>
							</div>
						</div>
								
					</div>
				</div>
				<!-- /.modal-body -->
				<div class="modal-footer">
					<button type="submit" class="btn btn-primary"><i class="fa fa-save fa-fw"></i> Simpan</button>
					<button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
				</div>
				<!-- /.modal-footer -->
			</div>
			<!-- /.modal-content -->
		</div>
		<!-- /.modal-dialog -->
	</div>
</form>
<script>
	$('select').select2();
</script>
