<?php
/**
	* CodeIgniter Core Model
	*
	* @package         CodeIgniter
	* @subpackage      Controller
	* @category        Anggaran Pengeluaran Controller
	* @author          
	* @version         1.1
*/
defined('BASEPATH') OR exit('No direct script access allowed');

class Anggaran_pengeluaran extends MY_Controller
{
    function __construct()
    {
        parent::__construct();
		$this->load->model('Anggaran_pengeluaran_model');
		$config['table'] = 'trs_blud';
		$config['column_order'] = array(null,'id','id_anggaran','no_cek','tgl_blud','uraian','jumlah','ppn','id_kategori_pph','pph','setoran','kategori_belanja',null);
		$config['column_search'] = array('id','id_anggaran','no_cek','tgl_blud','uraian','jumlah','ppn','id_kategori_pph','pph','setoran','kategori_belanja');
		$config['column_excel'] = array('id','id_anggaran','no_cek','tgl_blud','uraian','jumlah','ppn','id_kategori_pph','pph','setoran','kategori_belanja');
		$config['column_pdf'] = array('trs_blud.id','anggaran.nama_anggaran','anggaran.no_rekening','trs_blud.no_cek','trs_blud.tgl_blud','trs_blud.uraian','trs_blud.jumlah','trs_blud.ppn','trs_blud.id_kategori_pph','trs_blud.pph');
		$config['order'] = array('trs_blud.id' => 'asc');
		$this->Anggaran_pengeluaran_model->initialize($config);
    }

    public function index()
    {
		$data['title'] = 'Anggaran_pengeluaran';
		$data['id_table'] = 'anggaran_pengeluaran';
		$data['datatable_list'] = 'anggaran_pengeluaran/ajax_list';
		$data['datatable_edit'] = 'anggaran_pengeluaran/ajax_edit';
		$data['datatable_delete'] = 'anggaran_pengeluaran/ajax_delete';
		$data['datatable_save'] = 'anggaran_pengeluaran/ajax_save';

		$data['kategori_pph'] = $this->db->select('id,nama_pph')
		->get('ms_kategori_pph')->result_array();
		$data['anggaran'] = $this->db->select('id,nama_anggaran,no_rekening')
		->get('anggaran')->result_array();
				
		$data['load_form'] = $this->load_form($data);
		$this->template->display('anggaran_pengeluaran',$data);
    }

    public function load_form($data)
	{
		return $this->load->view('form_anggaran_pengeluaran',$data,true);
	}

    public function ajax_list()
	{	
		$list = $this->Anggaran_pengeluaran_model->get_datatables();
		$data = array();
		$no = $_POST['start'];
		foreach ($list as $row) {
			$no++;
			$fields = array();
			$fields[] = $row->id;
			$fields[] = $no;
			
			 $fields[] = $row->nama_anggaran;
			 $fields[] = $row->no_rekening;
			 $fields[] = $row->no_cek;
			 $fields[] = $row->tgl_blud;
			 $fields[] = $row->uraian;
			 $fields[] = rupiah($row->jumlah);
			 $fields[] = rupiah($row->ppn);
			 $fields[] = $row->id_kategori_pph;
			 $fields[] = rupiah($row->pph);
			 $fields[] = rupiah($row->setoran);
			 $fields[] = $row->kategori_belanja;
			$fields[] = $row->id;
			
			$data[] = $fields;
		}

		$output = array(
			"draw" => $_POST['draw'],
			"recordsTotal" => $this->Anggaran_pengeluaran_model->count_all(),
			"recordsFiltered" => $this->Anggaran_pengeluaran_model->count_filtered(),
			"data" => $data,
		);

		echo json_encode($output);
	}

	public function ajax_edit($id=0)
	{
		$data_object = $this->Anggaran_pengeluaran_model->get_by_id($id);
		if($data_object)
		{
			$list_fields = array(
			 'id',
			 'id_anggaran',
			 'no_cek',
			 'tgl_anggaran_pengeluaran',
			 'uraian',
			 'jumlah',
			 'ppn',
			 'id_kategori_pph',
			 'pph',
			 'kategori_belanja'
			);
			
			$fields = $this->Anggaran_pengeluaran_model->list_fields($list_fields);
			$data = (array) $data_object;

			if(!empty($data['kategori_belanja'])){
				
				$kategori_belanja = explode(',',$data['kategori_belanja']);
				$data['ls'] = $kategori_belanja[0];
				$data['gu'] = $kategori_belanja[1];
			}
								
			foreach($fields as $meta){
				$data_new['name'] = $meta->name;
				$data_new['value'] = $data[$meta->name];
				$data_array[] = $data_new;
			}
			
			$result['status'] = 0;
			$result['data_array'] = $data_array;
			$result['data_object'] = $data_object;
			$response['response'] = $result;
		}
		else
		{
			$result['status'] = 99;
			$response['response'] = $result;
		}
		echo json_encode($response);
	}

	public function ajax_save()
	{
		$post = $this->input->post(NULL,TRUE);
		$jumlah = (int)rupiah_to_number($post['jumlah']);
		$ppn = (int)rupiah_to_number($post['ppn']);
		$pph = (int)rupiah_to_number($post['pph']);
		
		if(isset($post['ppn']) || isset($post['pph'])){
			$setoran = $jumlah-($ppn+$pph);
		}

		if(isset($post['ls']) && isset($post['gu'])){
			$kategori_belanja = $post['ls'].",".$post['gu'];
		}else{
			$kategoir_belanja = (isset($post['ls']))?$post['ls']:$post['gu'];
		}
		$data = array(
			 'id_anggaran' => $post['id_anggaran'],	
			 'no_cek' => $post['no_cek'],	
			 'tgl_blud' => convert_tgl($post['tgl_blud'],'Y-m-d',1),
			 'uraian' => $post['uraian'],	
			 'jumlah' => $jumlah,	
			 'ppn' => $ppn,	
			 'id_kategori_pph' => $post['id_kategori_pph'],	
			 'pph' => $pph,	
			 'setoran' => $setoran,
			 'kategori_belanja' => $kategori_belanja
		);

		$data2 = array(
			 'id_anggaran' => $post['id_anggaran'],	
			 'jumlah_jurnal' => $jumlah,	
			 'tipe_jurnal' => 'kredit',	
			 'tanggal_jurnal' => convert_tgl($post['tgl_blud'],'Y-m-d',1),
			 'uraian' => $post['uraian']
		);
	
		if(empty($post['id']))
		{
			$result = $this->Anggaran_pengeluaran_model->insert($data);
			$result = $this->Anggaran_pengeluaran_model->insert_jurnal($data2);
		}
		else
		{
			$result = $this->Anggaran_pengeluaran_model->update(array('id' => $post['id']), $data);
			$result = $this->Anggaran_pengeluaran_model->update_jurnal(array('id' => $post['id']), $data2);

		}
		
		echo json_encode(array("status" => true));
		
	}
  

	public function ajax_delete()
	{
		$post = $this->input->post(NULL,TRUE);
		$id = $post['id'];
		if(!is_array($id)){
			$id[] = $id;
		}
		$this->Anggaran_pengeluaran_model->delete($id);
		echo json_encode(array("status" => TRUE));
	}
  
	public function excel()
	{
		$this->load->library("Excel");

		$query = $this->Anggaran_pengeluaran_model->data_excel("trs_blud");
		$this->excel->export($query);
	}
	
	public function pdf_pendukung()
	{
		$this->load->library("Chtml2pdf");
		$this->load->library('currency');
		
		$data = array();
		$query1 = $this->Anggaran_pengeluaran_model->data_pdf1();
		$data['query1'] = $query1;
		$content = $this->load->view('pdf_anggaran_pengeluaran',$data,true);
		
		$this->chtml2pdf->cetak("P","A4",$content,"dokumen_pendukung","I"); 
	}
	
	public function get_no_rekening(){
		
		@extract($_POST);
		$query = $this->db->select('no_rekening')->where('id',$id)->get('anggaran')->row();
		echo $query->no_rekening;
	}
	
	public function get_anggaran(){
		$search = ($_GET['q'])?strip_tags(trim($_GET['q'])):'';
		$query = $this->db->select('id,nama_anggaran')
		->like('nama_anggaran',$search)
		->get('anggaran')->result_array();
		$data = array();
		$found = count($query);
		if($found > 0){
			foreach($query as $r){
				$field = array();
				$field['id'] = $r['id'];
				$field['text'] = $r['nama_anggaran'];
				$field['name'] = $r['nama_anggaran'];
				$data[] = $field;
			}
		}else{
			$data = array(
					'id' => '',
					'text' => 'Parent tidak di temukan'
					);
		}
		echo json_encode($data);
	}
	
	public function get_kategori_pph(){
		$search = ($_GET['q'])?strip_tags(trim($_GET['q'])):'';
		$query = $this->db->select('id,nama_pph')
		->like('nama_pph',$search)
		->get('ms_kategori_pph')->result_array();
		$data = array();
		$found = count($query);
		if($found > 0){
			foreach($query as $r){
				$field = array();
				$field['id'] = $r['id'];
				$field['text'] = $r['nama_pph'];
				$field['name'] = $r['nama_pph'];
				$data[] = $field;
			}
		}else{
			$data = array(
					'id' => '',
					'text' => 'Parent tidak di temukan'
					);
		}
		echo json_encode($data);
	}
}
?>
