<?php
/**
	* CodeIgniter Core Model
	*
	* @package         CodeIgniter
	* @subpackage      Controller
	* @category        Pagu Controller
	* @author          
	* @version         1.1
*/
defined('BASEPATH') OR exit('No direct script access allowed');

class Pagu extends MY_Controller
{
    function __construct()
    {
        parent::__construct();
		$this->load->model('Pagu_model');
		$config['table'] = 'pagu';
		$config['column_order'] = array(null,'id','id_biaya','pagu','id_periode',null);
		$config['column_search'] = array('id','id_biaya','pagu','id_periode');
		$config['column_excel'] = array('id','id_biaya','pagu','id_periode');
		$config['column_pdf'] = array('id','id_biaya','pagu','id_periode');
		$config['order'] = array('id' => 'asc');
		$this->Pagu_model->initialize($config);
    }

    public function index()
    {
		$data['title'] = 'Pagu';
		$data['id_table'] = 'pagu';
		$data['datatable_list'] = 'pagu/ajax_list';
		$data['datatable_edit'] = 'pagu/ajax_edit';
		$data['datatable_delete'] = 'pagu/ajax_delete';
		$data['datatable_save'] = 'pagu/ajax_save';
		
		$data['load_form'] = $this->load_form($data);
		$this->template->display('pagu',$data);
    }

    public function load_form($data)
	{
		return $this->load->view('form_pagu',$data,true);
	}

    public function ajax_list()
	{	
		$list = $this->Pagu_model->get_datatables();
		$data = array();
		$no = $_POST['start'];
		foreach ($list as $row) {
			$no++;
			$fields = array();
			$fields[] = $row->id;
			$fields[] = $no;
			
			 $fields[] = $row->id_anggaran;
			 $fields[] = rupiah($row->pagu);
			 $fields[] = $row->id_periode;
			 
			$fields[] = $row->id;
			$data[] = $fields;
		}

		$output = array(
			"draw" => $_POST['draw'],
			"recordsTotal" => $this->Pagu_model->count_all(),
			"recordsFiltered" => $this->Pagu_model->count_filtered(),
			"data" => $data,
		);

		echo json_encode($output);
	}
	
	public function ajax_edit($id=0)
	{
		$data_object = $this->Pagu_model->get_by_id($id);
		if($data_object)
		{
			$list_fields = array(
			 'id',
			 'id_anggaran',
			 'pagu',
			 'id_periode',
			);
			
			$fields = $this->Pagu_model->list_fields($list_fields);
			//foreach($fields as $fields){
				//$fields['no_rekening'] = str.split
			//}
			$data = (array) $data_object;
			
			foreach($fields as $meta){
				$data_new['name'] = $meta->name;
				$data_new['value'] = $data[$meta->name];
				$data_array[] = $data_new;
			}
			
			$result['status'] = 0;
			$result['data_array'] = $data_array;
			$result['data_object'] = $data_object;
			$response['response'] = $result;
		}
		else
		{
			$result['status'] = 99;
			$response['response'] = $result;
		}
		echo json_encode($response);
	}

	public function ajax_save()
	{
		$post = $this->input->post(NULL,TRUE);
		$data = array(
			 'id_anggaran' => $post['id_anggaran'],
			 'pagu' => rupiah_to_number($post['pagu']),
			 'id_periode' => $post['id_periode']
		);
			
		if(empty($post['id']))
		{
			$result = $this->Pagu_model->insert($data);
		}
		else
		{
			$result = $this->Pagu_model->update(array('id' => $post['id']), $data);
		}
		
		echo json_encode(array("status" => true,"ID" => $post['id'],"ID Anggaran" => $post['id_anggaran']));
		
	}
  

	public function ajax_delete()
	{
		$post = $this->input->post(NULL,TRUE);
		$id = $post['id'];
		if(!is_array($id)){
			$id[] = $id;
		}
		$this->Pagu_model->delete($id);
		echo json_encode(array("status" => TRUE));
	}
  
	public function excel()
	{
		$this->load->library("Excel");

		$query = $this->Pagu_model->data_excel("pagu");
		$this->excel->export($query);
	}
	
	public function pdf()
	{
		$this->load->library("Chtml2pdf");
		$this->load->library("Header_file");
		
		$query = $this->Pagu_model->data_pdf();
		$data['header'] = $this->header_file->pdf('100%');
		$data['query'] = $query;
		$content = $this->load->view('pdf_pagu',$data,true);
		$this->chtml2pdf->cetak("P","A4",$content,"Pagu","I"); 
	}
	
	public function get_anggaran(){
		$search = ($_GET['q'])?strip_tags(trim($_GET['q'])):'';
		$query = $this->db->select('id,no_rekening,nama_anggaran')
		->where('nama_anggaran',$search)
		->get('anggaran')->result_array();
		$data = array();
		$found = count($query);
		if($found > 0){
			foreach($query as $r){
				$data['id'] = $r['id'];
				$data['text'] = $r['nama_anggaran'];
			}
		}else{
			$data = array(
					'id' => '',
					'text' => 'Anggaran tidak di temukan'
					);
		}
		return $data;
	}
	
	public function get_periode{
		$search = ($_GET['q'])?strip_tags(trim($_GET['q'])):'';
		$data['periode'] = $this->db->select('id,nama_periode')
		->where('nama_anggaran',$search)
		->get('periode_pagu')->result_array();
		$data = array();
		$found = count($query);
		if($found > 0){
			foreach($query as $r){
				$data['id'] = $r['id'];
				$data['text'] = $r['nama_periode'];
			}
		}else{
			$data = array(
					'id' => '',
					'text' => 'Periode tidak di temukan'
					);
		}
		return $data;
}	}
?>
