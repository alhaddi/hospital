<?php
	/**
		* CodeIgniter Core Model
		*
		* @package         CodeIgniter
		* @subpackage      Controller
		* @category        Konsultasi Controller
		* @author          Amir Mufid
		* @version         1.1
	*/
	defined('BASEPATH') OR exit('No direct script access allowed');
	
	class Konsultasi extends MY_Controller
	{
		function __construct()
		{
			parent::__construct();
			$this->load->model('Konsultasi_model');
			$this->load->model('billing/Billing_model');
			$config['table'] = 'trs_konsultasi';
			$config['column_order'] = array(
			null,
			'trs_konsultasi.id',
			'ms_pasien.rm',
			'ms_pasien.nama_lengkap',
			'ms_pasien.tipe_identitas',
			'ms_pasien.no_identitas',
			'ms_cara_bayar.nama',
			'ms_poliklinik.nama',
			'trs_konsultasi.add_time',
			null
			);
			$config['column_search'] = array(
			'trs_konsultasi.id',
			'ms_pasien.rm',
			'ms_pasien.nama_lengkap',
			'ms_pasien.tipe_identitas',
			'ms_pasien.no_identitas',
			'ms_cara_bayar.nama',
			'ms_poliklinik.nama',
			'trs_konsultasi.add_time'
			);
			$config['column_excel'] = array(
			'trs_konsultasi.id',
			'ms_pasien.rm',
			'ms_pasien.nama_lengkap',
			'ms_pasien.tipe_identitas',
			'ms_pasien.no_identitas',
			'ms_cara_bayar.nama',
			'ms_poliklinik.nama',
			'trs_konsultasi.add_time'
			);
			$config['column_pdf'] = array(
			'trs_konsultasi.id',
			'ms_pasien.rm',
			'ms_pasien.nama_lengkap',
			'ms_pasien.tipe_identitas',
			'ms_pasien.no_identitas',
			'ms_cara_bayar.nama',
			'ms_poliklinik.nama',
			'trs_konsultasi.add_time'
			);
			$config['order'] = array('trs_konsultasi.id' => 'desc');
			$this->Konsultasi_model->initialize($config);
		}
		
		public function index()
		{
			$data['title'] = 'Konsultasi';
			$data['id_table'] = 'konsultasi';
			$data['datatable_list'] = 'konsultasi/ajax_list';
			$data['datatable_edit'] = 'konsultasi/ajax_edit';
			$data['datatable_delete'] = 'konsultasi/ajax_delete';
			$data['datatable_save'] = 'konsultasi/ajax_save';
			$this->template->display('konsultasi',$data);
		}
		
		
		public function ajax_list()
		{	
			$list = $this->Konsultasi_model->get_datatables();
			$data = array();
			$no = $_POST['start'];
			foreach ($list as $row) {
				$no++;
				$fields = array();
				
				$fields[] = $no;
				$fields[] = $row->rm;
				$fields[] = $row->nama_lengkap;
				$fields[] = $row->tipe_identitas.' '.$row->no_identitas;
				$fields[] = $row->cara_bayar;
				$fields[] = $row->jenis_appointment;
				$fields[] = $row->poliklinik;
				$fields[] = convert_tgl($row->add_time,'d M Y H:i',1);
				$fields[] = ($row->status == 1)?'<i class="label label-success">Sudah</i>':'<i class="label label-danger">Belum</i>';
				$fields[] = '<a href="'.site_url('konsultasi/form_konsultasi/'.$row->id).'" class="btn btn-default"><i class="flaticon-doctor-2"></i> Konsulasi</button>';
				
				$data[] = $fields;
			}
			
			$output = array(
			"draw" => $_POST['draw'],
			"recordsTotal" => $this->Konsultasi_model->count_all(),
			"recordsFiltered" => $this->Konsultasi_model->count_filtered(),
			"data" => $data,
			);
			
			echo json_encode($output);
		}
				
		function modal_mr(){
			$post = $this->input->post(NULL,TRUE);
			$PasienID=element('PasienID',$post);
			$KonsultasiID=element('KonsultasiID',$post);
			$id=$this->db->query("SELECT
	trs_konsultasi.id,
	ms_poliklinik.nama,
	trs_appointment.add_time
FROM
trs_appointment ,
ms_poliklinik ,
trs_konsultasi,trs_anamesa,trs_poliklinik
WHERE trs_anamesa.id_appointment = trs_appointment.id AND trs_konsultasi.id_anamesa = trs_anamesa.id
AND trs_poliklinik.PoliklinikID = ms_poliklinik.id AND trs_poliklinik.PoliklinikID = trs_appointment.id_poliklinik
AND
 trs_appointment.id_pasien = '$PasienID' AND trs_konsultasi.id !='$KonsultasiID' GROUP BY id_anamesa
")->result();
echo "<div id='detail_mr'><table class='table table-striped table-bordered table-hover'>
		<thead>
		<tr>
			<th style='text-align:center'>No</th>
			<th style='text-align:center'>Poliklinik</th>
			<th style='text-align:center'>Tanggal</th>
			<th style='text-align:center'>Action</th>
		</tr>
		</thead>
			";
			$n=1;
			foreach($id as $r){
			echo "
		<tr>
			<td>$n</td>
			<td>$r->nama</td>
			<td style='text-align:center'>$r->add_time</td>
			<td style='text-align:center'><button onclick='load_mr($r->id)' class='btn btn-info' type='button'>Lihat Riwayat</button></td>
		</tr>";
			$n++; }
echo "</table></div>";
echo '<center><button type="button" class="btn btn-danger" data-dismiss="modal">Tutup</button></center>';
		}
		
		public function form_konsultasi($id,$ket="")
		{
			$data['ket'] = $ket;
			$data['title'] = 'Konsultasi';
			$data['id_table'] = 'konsultasi';
			$data['datatable_save'] = 'konsultasi/ajax_save';
			
			$data['cara_bayar'] = $this->db->select('id,nama')->get('ms_cara_bayar')->result_array();
			$data['poliklinik'] = $this->db->get('ms_poliklinik')->result_array();
			$data['jenis_appointment'] = $this->db->get('ms_jenis_appointment')->result_array();
			$data['bpjs_type'] = $this->db->get('ms_bpjs_type')->result_array();
			
			
			$data['konsultasi'] = $konsultasi = $this->db->select('
			trs_konsultasi.id,
			trs_konsultasi.id as rowid,
			trs_appointment.id_jenis_appointment,
			trs_appointment.id_cara_bayar,
			trs_appointment.id_bpjs_type,
			trs_appointment.no_bpjs,
			trs_appointment.no_polis,
			trs_appointment.nama_perusahaan,
			trs_konsultasi.catatan,
			trs_konsultasi.id_anamesa,
			ms_pasien.id as id_pasien,
			ms_pasien.rm,
			ms_pasien.nama_lengkap,
			ms_pasien.usia,
			ms_pasien.jk,
			ms_pasien.alamat,
			ms_pasien.tanggal_lahir,
			ms_poliklinik.nama as poliklinik
			')
			->where('trs_konsultasi.id',$id)
			->join('trs_anamesa','trs_anamesa.id = trs_konsultasi.id_anamesa','inner')
			->join('trs_appointment','trs_appointment.id = trs_anamesa.id_appointment','inner')
			->join('ms_pasien','ms_pasien.id = trs_appointment.id_pasien','inner')
			->join('ms_poliklinik','ms_poliklinik.id = trs_appointment.id_poliklinik','inner')
			->get('trs_konsultasi')->row_array();
			
			$data['anamesa'] = $this->db->select('
			ms_komponen_anamesa.nama,
			ms_komponen_anamesa.satuan,
			ms_komponen_anamesa.icon,
			trs_anamesa_detail.hasil,
			trs_anamesa_detail.id_anamesa,
			trs_anamesa_detail.id_ms_anamesa
			')
			->where('id_anamesa',$konsultasi['id_anamesa'])
			->join('ms_komponen_anamesa','ms_komponen_anamesa.id = trs_anamesa_detail.id_ms_anamesa','inner')
			->get('trs_anamesa_detail')->result_array();
			
			$data['diagnosa'] = $diagnosa = $this->db->select('
			trs_diagnosa.id,
			trs_diagnosa.id as rowid,
			trs_diagnosa.code,
			trs_diagnosa.type,
			tb_data_icd.deskripsi,
			trs_diagnosa.catatan
			')
			->where('trs_diagnosa.id_konsultasi',$id)
			->join('tb_data_icd','tb_data_icd.code = trs_diagnosa.code','inner')
			->get('trs_diagnosa')->result_array();
			
			$data['tindakan'] = $tindakan = $this->db->select('
			trs_tindakan.id,
			trs_tindakan.id as rowid,
			trs_tindakan.jumlah_tindakan as jumlah,
			trs_tindakan.biaya,
			trs_tindakan.keterangan,
			ms_tindakan.id as id_ms_tindakan,
			ms_tindakan.nama
			')
			->where('trs_tindakan.id_konsultasi',$id)
			->join('ms_tindakan','ms_tindakan.id = trs_tindakan.id_ms_tindakan','inner')
			->get('trs_tindakan')->result_array();
			
			$data['penunjang'] = $tindakan = $this->db->select('
			trs_penunjang.id as rowid,
			trs_penunjang.*,
			ms_penunjang.nama as namapenunjang,
			ms_penunjang.biaya as biayapenunjang
			')->where('trs_penunjang.id_konsultasi',$id)->join('ms_penunjang','ms_penunjang.id = trs_penunjang.id_ms_penunjang','inner')->get('trs_penunjang')->result_array();
			$this->template->display('form_konsultasi',$data);
		}
		public function ajax_edit($id=0)
		{
			$data_object = $this->Konsultasi_model->get_by_id($id);
			if($data_object)
			{
				$list_fields = array(
				'id',
				'id_anamesa',
				'add_time',
				'last_update',
				);
				
				$fields = $this->Konsultasi_model->list_fields($list_fields);
				$data = (array) $data_object;
				
				foreach($fields as $meta){
					$data_new['name'] = $meta->name;
					$data_new['value'] = $data[$meta->name];
					$data_array[] = $data_new;
				}
				
				$result['status'] = 0;
				$result['data_array'] = $data_array;
				$result['data_object'] = $data_object;
				$response['response'] = $result;
			}
			else
			{
				$result['status'] = 99;
				$response['response'] = $result;
			}
			$this->getbilling($id);
			echo json_encode($response);
		}
		
		public function ajax_save()
		{
			$post = $this->input->post(NULL,TRUE);
			
			if(!empty($post['penunjang']))
			{
				$value = $post['penunjang'];
				foreach($value['id_ms_penunjang'] as $index=>$val)
				{
					$kategori=$value['kategori'][$index];
					$penunjang['id'] = $value['id'][$index];
					$penunjang['id_ms_penunjang'] = $value['id_ms_penunjang'][$index];
				//	$penunjang['id_ms_poliklinik'] = $value['id_ms_poliklinik'][$index];
					$penunjang['klinis'] = $value['klinis'][$index];
					$penunjang['nama_dokter'] = $value['nama_dokter'][$index];
					$penunjang['kategori'] = $value['kategori'][$index];
					$biaya=get_field($penunjang['id_ms_penunjang'],'ms_penunjang','biaya');
					$penunjang['biaya'] = $value['biaya'][$index];
					$penunjang['jumlah'] = $value['jumlah'][$index];
					$penunjang['id_konsultasi'] = element('id',$post);
					$penunjang['keterangan'] = $value['keterangan'][$index];
					$penunjang_batch[] = $penunjang;
				}
				
				$this->db->replace_batch('trs_penunjang',$penunjang_batch);		
				$this->getbilling(element('id',$post));				
			}
			if(!empty($post['tindakan']))
			{
				$value = $post['tindakan'];
				foreach($value['id_ms_tindakan'] as $index=>$val)
				{
					$tindakan['id'] = $value['id'][$index];
					$tindakan['id_ms_tindakan'] = $value['id_ms_tindakan'][$index];
					$tindakan['jumlah_tindakan'] = $value['jumlah'][$index];
					$tindakan['id_konsultasi'] = element('id',$post);
					$tindakan['biaya'] = $value['biaya'][$index];
					$tindakan['keterangan'] = $value['keterangan'][$index];
					$tindakan_batch[] = $tindakan;
				}
				
				$this->db->replace_batch('trs_tindakan',$tindakan_batch);		
				$this->getbilling(element('id',$post));				
			}
			
			if(!empty($post['diagnosa']))
			{
				foreach($post['diagnosa'] as $type=>$item)
				{
					foreach($item['code'] as $index=>$val)
					{
						$diagnosa['id'] = $item['id'][$index];
						$diagnosa['code'] = $item['code'][$index];
						$diagnosa['catatan'] = $item['catatan'][$index];
						$diagnosa['type'] = $type;
						$diagnosa['id_konsultasi'] = element('id',$post);
						$diagnosa_batch[] = $diagnosa;
					}
					
				}
				$this->db->replace_batch('trs_diagnosa',$diagnosa_batch);			
			}
			
			$konsultasi['status'] = 1;
			$konsultasi['catatan'] = element('catatan',$post);
			$this->db->where('id',element('id',$post))->update('trs_konsultasi',$konsultasi);
			
			$response = array(
			'status' => true,
			'message' => 'Konsulasi telah selesai di proses !',
			'redirect' => site_url('konsultasi')
			);
			echo json_encode($response);
		}
		
		
		public function ajax_delete_diagnosa($icd)
		{
			$post = $this->input->post(NULL,TRUE);
			$diagnosa = $post['diagnosa'][$icd];
			$id = $diagnosa['rowid'];
			//		var_dump($id);
			$this->Konsultasi_model->delete_diagnosa($id);
			echo json_encode(array("status" => TRUE));
			
		}
		
		public function ajax_delete_penunjang()
		{
			$post = $this->input->post(NULL,TRUE);
			$penunjang = $post['penunjang'];
			$id = $penunjang['rowid'];
			//		var_dump($id);
			$im=implode(",",$id);
			$i=$this->db->query("SELECT id_konsultasi FROM trs_penunjang WHERE ID IN ($im) LIMIT 1")->row();
			$this->Konsultasi_model->delete_penunjang($id);
			$this->getbilling($i->id_konsultasi);
			
			echo json_encode(array("status" => TRUE));
			
			
		}
		
		public function ajax_delete_tindakan()
		{
			$post = $this->input->post(NULL,TRUE);
			$tindakan = $post['tindakan'];
			$id = $tindakan['rowid'];
			//		var_dump($id);
			$im=implode(",",$id);
			$i=$this->db->query("SELECT id_konsultasi FROM trs_tindakan WHERE ID IN ($im) LIMIT 1")->row();
			$this->Konsultasi_model->delete_tindakan($id);
			$this->getbilling($i->id_konsultasi);
			
			echo json_encode(array("status" => TRUE));
			
			
		}
		
		public function excel()
		{
			$this->load->library("Excel");
			
			$query = $this->Konsultasi_model->data_excel("konsultasi");
			$this->excel->export($query);
		}
		
		public function pdf()
		{
			$this->load->library("Chtml2pdf");
			$this->load->library("Header_file");
			
			$query = $this->Konsultasi_model->data_pdf();
			$data['header'] = $this->header_file->pdf('100%');
			$data['query'] = $query;
			$content = $this->load->view('pdf_konsultasi',$data,true);
			$this->chtml2pdf->cetak("P","A4",$content,"Konsultasi","I"); 
		}
		
		public function anamesa_edit($id_ms_anamesa,$id_anamesa){
			$post = $this->input->post(NULL,TRUE);
			$update['hasil'] = element('value',$post);
			$this->db
			->where('id_ms_anamesa',$id_ms_anamesa)
			->where('id_anamesa',$id_anamesa)
			->update('trs_anamesa_detail',$update);
		}
		
		public function json_diagnosa()
		{
			$get = $this->input->get(NULL,TRUE);
			$search = strip_tags(trim(element('q',$get)));
			$page = strip_tags(trim(element('page',$get)));
			
			$limit=50;
			$offset=($limit*$page);
			
			$this->db->select('
			tb_data_icd.code,
			tb_data_icd.deskripsi,
			tb_data_icd.type
			');
			$this->db->where('type',$get['type']);
			$this->db->group_start(); 
			$this->db->like('tb_data_icd.code', $search,'both');
			$this->db->or_like('tb_data_icd.deskripsi', $search,'both');
			$this->db->group_end();
			
			if($limit){
				$this->db->limit($limit, $offset);
				
			}
			$data = $this->db->get('tb_data_icd')->result();
			$found=count($data);
			
			if($found > 0){
				foreach ($data as $key => $value) {
					$data[] = array(
					'id' => $value->code,
					'text' => $value->code.' | '.$value->deskripsi
					);
				}
				} else {
				$data[] = array(
				'id' => '',
				'text' => 'Data tidak ditemukan.'
				);
			}
			
			$this->db->select('
			COUNT(tb_data_icd.code) as total_row
			',false);	
			$this->db->where('type',$get['type']);
			$total_row = $this->db->get('tb_data_icd')->row();
			
			$result['total_count'] = $total_row->total_row;
			$result['items'] = $data;
			// return the result in json
			echo json_encode($result);
		}
		
		public function json_getbiaya()
		{
			$jumlah=$this->input->post("jumlah");
			$IDTindakan=$this->input->post("IDTindakan");
			$data["hasil"]=get_field($IDTindakan,'ms_tindakan','biaya')*$jumlah;
			echo json_encode($data);
			
		}
		public function json_getbiayapenunjang()
		{
			$jumlah=$this->input->post("jumlah");
			$IDPenunjang=$this->input->post("IDPenunjang");
			$data["hasil"]=get_field($IDPenunjang,'ms_penunjang','biaya')*$jumlah;
			echo json_encode($data);
			
		}
		
		function getbilling($id_konsultasi){
			$cekid=$this->db->query("SELECT
			trs_anamesa.id_appointment
			FROM
			trs_konsultasi
			INNER JOIN trs_anamesa ON trs_konsultasi.id_anamesa = trs_anamesa.id
			WHERE trs_konsultasi.id='$id_konsultasi' LIMIT 1
			")->row();
			
			$cektindakan=$this->db->query("SELECT id FROM trs_billing WHERE id_appointment='$cekid->id_appointment' AND id_komponen='4'")->row();
			
			$cekpenunjang=$this->db->query("SELECT id FROM trs_billing WHERE id_appointment='$cekid->id_appointment' AND id_komponen='5'")->row();
			
			$getbill=$this->db->query("SELECT SUM(biaya) as jumlah FROM trs_tindakan WHERE id_konsultasi='$id_konsultasi'")->row();
			
			$getbill2=$this->db->query("SELECT SUM(biaya) as jumlah FROM trs_penunjang WHERE id_konsultasi='$id_konsultasi'")->row();
			
			if(!empty($cekpenunjang->id)){
				if($getbill2->jumlah <= 0 OR $getbill2->jumlah == "" OR $getbill2->jumlah == NULL){
					$this->db->where('id',$cekpenunjang->id);
					$this->db->delete("trs_billing");
					}else{
					$u['nominal']=$getbill2->jumlah;
					$u = array_filter($u);
					$this->db->where("id",$cekpenunjang->id);
					$this->db->update("trs_billing",$u);
					}	
				}else{
				if($getbill2->jumlah > 0 OR $getbill2->jumlah != "" OR $getbill2->jumlah != NULL){				
				$no_tagihan = $this->db->select('CONCAT(YEAR(NOW()),LPAD(ifnull(max(RIGHT(no_tagihan,5))+1,1),5,0)) as max_no_tagihan',false)
				->where('left(no_tagihan,4) = YEAR(NOW())',null,false)
				->get('trs_billing')->row();
				
				$i['id_appointment']=$cekid->id_appointment;
				$i['id_komponen']=5;
				$i['id_jenis_bayar']=1;
				$i['no_tagihan']=$no_tagihan->max_no_tagihan;;
				$i['nominal']=$getbill2->jumlah;
				$i['total_bayar']=0;
				$this->db->insert("trs_billing",$i);
				}
			}
			
			if(!empty($cektindakan->id)){
				if($getbill->jumlah <= 0  OR $getbill->jumlah == "" OR $getbill->jumlah == NULL){
					$this->db->where('id',$cektindakan->id);
					$this->db->delete("trs_billing");
					}else{
					$u['nominal']=$getbill->jumlah;
					$this->db->where("id",$cektindakan->id);
					$this->db->update("trs_billing",$u);
				}	
				}else{
				if($getbill->jumlah > 0  OR $getbill->jumlah != "" OR $getbill->jumlah != NULL){				
				$no_tagihan = $this->db->select('CONCAT(YEAR(NOW()),LPAD(ifnull(max(RIGHT(no_tagihan,5))+1,1),5,0)) as max_no_tagihan',false)
				->where('left(no_tagihan,4) = YEAR(NOW())',null,false)
				->get('trs_billing')->row();
				
				$i['id_appointment']=$cekid->id_appointment;
				$i['id_komponen']=4;
				$i['id_jenis_bayar']=1;
				$i['no_tagihan']=$no_tagihan->max_no_tagihan;;
				$i['nominal']=$getbill->jumlah;
				$i['total_bayar']=0;
				$this->db->insert("trs_billing",$i);
				}
			}
		}
		
		public function json_tindakan()
		{
			$get = $this->input->get(NULL,TRUE);
			$search = strip_tags(trim(element('q',$get)));
			$page = strip_tags(trim(element('page',$get)));
			
			$limit=50;
			$offset=($limit*$page);
			
			$this->db->select('
			ms_tindakan.id,
			ms_tindakan.nama,
			ms_tindakan.biaya,
			ms_kategori_tindakan.nama as kategori_tindakan
			');
			$this->db->group_start(); 
			$this->db->like('ms_tindakan.nama', $search,'both');
			$this->db->or_like('ms_kategori_tindakan.nama', $search,'both');
			$this->db->group_end();
			
			if($limit){
				$this->db->limit($limit, $offset);
			}
			$this->db->join('ms_kategori_tindakan','ms_kategori_tindakan.id = ms_tindakan.id_kategori_tindakan','inner');
			$data = $this->db->get('ms_tindakan')->result();
			$found=count($data);
			
			if($found > 0){
				foreach ($data as $key => $value) {
					$data[] = array(
					'id' => $value->id,
					'text' => $value->nama.' ('.$value->kategori_tindakan.') - '.rupiah($value->biaya)
					);
				}
				} else {
				$data[] = array(
				'id' => '',
				'text' => 'Data tidak ditemukan.'
				);
			}
			
			$this->db->select('
			COUNT(ms_tindakan.id) as total_row
			',false);	
			$total_row = $this->db->get('ms_tindakan')->row();
			
			$result['total_count'] = $total_row->total_row;
			$result['items'] = $data;
			// return the result in json
			echo json_encode($result);
		}
		
		
		public function json_ms_poliklinik()
		{
			$get = $this->input->get(NULL,TRUE);
			$search = strip_tags(trim(element('q',$get)));
			$page = strip_tags(trim(element('page',$get)));
			
			
			$data = $this->db->get('ms_poliklinik')->result();
			$found=count($data);
			
			if($found > 0){
				foreach ($data as $key => $value) {
					$data[] = array(
					'id' => $value->id,
					'text' => $value->nama
					);
				}
				} else {
				$data[] = array(
				'id' => '',
				'text' => 'Data tidak ditemukan.'
				);
			}
			
			$this->db->select('
			COUNT(ms_poliklinik.id) as total_row
			',false);	
			$total_row = $this->db->get('ms_poliklinik')->row();
			
			$result['total_count'] = $total_row->total_row;
			$result['items'] = $data;
			// return the result in json
			echo json_encode($result);
		}
		
		public function json_ms_penunjang()
		{
			$get = $this->input->get(NULL,TRUE);
			$search = strip_tags(trim(element('q',$get)));
			$page = strip_tags(trim(element('page',$get)));
			
			$this->db->group_start();
				$this->db->like('nama',$search,'both');
			$this->db->group_end();
			$data = $this->db->get('ms_penunjang')->result();
			$found=count($data);
			
			if($found > 0){
				foreach ($data as $key => $value) {
					$data[] = array(
					'id' => $value->id,
					'text' => $value->nama
					);
				}
				} else {
				$data[] = array(
				'id' => '',
				'text' => 'Data tidak ditemukan.'
				);
			}
			
			$this->db->group_start();
				$this->db->like('nama',$search,'both');
			$this->db->group_end();
			$this->db->select('
			COUNT(ms_penunjang.id) as total_row
			',false);	
			$total_row = $this->db->get('ms_penunjang')->row();
			
			$result['total_count'] = $total_row->total_row;
			$result['items'] = $data;
			// return the result in json
			echo json_encode($result);
		}
		
		public function save_poliklinik_pasien(){
			$post = $this->input->post(NULL,TRUE);
			if($this->_save_poliklinik_pasien($post))
			{
				echo json_encode(array("status" => TRUE));
			}
		}
		

		function modal_penunjang(){
			$post = $this->input->post(NULL,TRUE);
			$PenunjangID=element('IDPenunjang',$post);
			$data["PenunjangID"]=element('IDPenunjang',$post);
			$data["listkategori"]=explode(",",element('listkategori',$post));
			$data["last_id"]=element('last_id',$post);
			$data["kelompok"]=$this->db->query("SELECT kelompok FROM ms_kategori_penunjang WHERE id_ms_penunjang='$PenunjangID' GROUP BY kelompok")->result();
			$this->load->view("modal_penunjang",$data);
		}
		
		private function _save_poliklinik_pasien($post){
			
			$this->db->trans_start();
			
			$insert['id_pasien'] = element('id_pasien',$post);
			$insert['id_jenis_appointment'] = element('id_jenis_appointment',$post);
			$insert['id_poliklinik'] = element('id_poliklinik',$post);
			$insert['id_cara_bayar'] = element('id_cara_bayar',$post);
			$insert['id_bpjs_type'] = element('id_bpjs_type',$post);
			$insert['no_bpjs'] = element('no_bpjs',$post);
			$insert['no_polis'] = element('no_bpjs',$post);
			$insert['nama_perusahaan'] = element('nama_perusahaan',$post);
			$insert = array_filter($insert);
			
			$this->db->insert('trs_appointment',$insert);
			$id_appointment = $this->db->insert_id();
			$this->db->where('id',element('id_pasien',$post))->update('ms_pasien',array('arrived_at'=>date('Y-m-d H:i:s')));
			if( $this->db->affected_rows() > 0 )
			{
				$no_tagihan = $this->Billing_model->no_tagihan();
				
				$komponen = $this->db->select('ms_komponen_registrasi.*')
				->get_where('ms_komponen_registrasi',array('id'=>element('id_komponen',$post)))->row_array();
				
				if(count($komponen))
				{
					$insert_tagihan['no_tagihan'] = $no_tagihan;
					$insert_tagihan['id_appointment'] = $id_appointment;
					$insert_tagihan['id_komponen'] = $komponen['id'];
					$insert_tagihan['nominal'] = $komponen['nominal'];
					$this->db->insert('trs_billing',$insert_tagihan);
				}
			}
			
			$this->db->trans_complete();
			if ($this->db->trans_status() === FALSE)
			{
				return false;
			}
			else
			{
				return true;
			}
		}
	}
?>
