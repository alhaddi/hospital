<?php
/**
	* CodeIgniter Core Model
	*
	* @package         CodeIgniter
	* @subpackage      Controller
	* @category        Anggaran_pemasukan Controller
	* @author          
	* @version         1.1
*/
defined('BASEPATH') OR exit('No direct script access allowed');

class Anggaran_pemasukan extends MY_Controller
{
    function __construct()
    {
        parent::__construct();
		$this->load->model('Anggaran_pemasukan_model');
		$config['table'] = 'jurnal';
		$config['column_order'] = array(null,'id','id_anggaran','tgl_blud','uraian','jumlah',null);
		$config['column_search'] = array('id','id_anggaran','tgl_blud','uraian','jumlah');
		$config['column_excel'] = array('id','id_anggaran','tgl_blud','uraian','jumlah');
		$config['column_pdf'] = array('jurnal.id','anggaran.nama_anggaran','anggaran.no_rekening','jurnal.tgl_blud','jurnal.uraian','trs_blud.jumlah');
		$config['order'] = array('jurnal.id' => 'asc');
		$this->Anggaran_pemasukan_model->initialize($config);
    }

    public function index()
    {
		$data['title'] = 'Anggaran_pemasukan';
		$data['id_table'] = 'anggaran_pemasukan';
		$data['datatable_list'] = 'anggaran_pemasukan/ajax_list';
		$data['datatable_edit'] = 'anggaran_pemasukan/ajax_edit';
		$data['datatable_delete'] = 'anggaran_pemasukan/ajax_delete';
		$data['datatable_save'] = 'anggaran_pemasukan/ajax_save';

		$data['anggaran'] = $this->db->select('id,nama_anggaran,no_rekening')
		->get('anggaran')->result_array();

		$data['load_form'] = $this->load_form($data);
		$this->template->display('anggaran_pemasukan',$data);
    }

    public function load_form($data)
	{
		return $this->load->view('form_anggaran_pemasukan',$data,true);
	}

    public function ajax_list()
	{	
		$list = $this->Anggaran_pemasukan_model->get_datatables();
		$data = array();
		$no = $_POST['start'];
		foreach ($list as $row) {
			$no++;
			$fields = array();
			$fields[] = $row->id;
			$fields[] = $no;
			
			 $fields[] = $row->nama_anggaran;
			 $fields[] = $row->no_rekening;
			 $fields[] = $row->tanggal_jurnal;
			 $fields[] = $row->uraian;
			 $fields[] = rupiah($row->jumlah_jurnal);
			$fields[] = $row->id;
			
			$data[] = $fields;
		}

		$output = array(
			"draw" => $_POST['draw'],
			"recordsTotal" => $this->Anggaran_pemasukan_model->count_all(),
			"recordsFiltered" => $this->Anggaran_pemasukan_model->count_filtered(),
			"data" => $data,
		);

		echo json_encode($output);
	}

	public function ajax_edit($id=0)
	{
		$data_object = $this->Anggaran_pemasukan_model->get_by_id($id);
		if($data_object)
		{
			$list_fields = array(
			 'id',
			 'id_anggaran',
			 'tanggal_jurnal',
			 'uraian',
			 'jumlah'
			);
			
			$fields = $this->Anggaran_pemasukan_model->list_fields($list_fields);
			$data = (array) $data_object;
			
			foreach($fields as $meta){
				$data_new['name'] = $meta->name;
				$data_new['value'] = $data[$meta->name];
				$data_array[] = $data_new;
			}
			
			$result['status'] = 0;
			$result['data_array'] = $data_array;
			$result['data_object'] = $data_object;
			$response['response'] = $result;
		}
		else
		{
			$result['status'] = 99;
			$response['response'] = $result;
		}
		echo json_encode($response);
	}

	public function ajax_save()
	{
		$post = $this->input->post(NULL,TRUE);
		$data = array(
			 'id_anggaran' => $post['id_anggaran'],	
			 'jumlah_jurnal' => rupiah_to_number($post['jumlah_jurnal']),
			 'tipe_jurnal' => 'debit',
			 'tanggal_jurnal' => convert_tgl($post['tanggal_jurnal'],'Y-m-d',1),
			 'uraian' => $post['uraian']

		);
			
		if(empty($post['id']))
		{
			$result = $this->Anggaran_pemasukan_model->insert($data);
		}
		else
		{
			$result = $this->Anggaran_pemasukan_model->update(array('id' => $post['id']), $data);
		}
		
		echo json_encode(array("status" => true));
		
	}
  

	public function ajax_delete()
	{
		$post = $this->input->post(NULL,TRUE);
		$id = $post['id'];
		if(!is_array($id)){
			$id[] = $id;
		}
		$this->Anggaran_pemasukan_model->delete($id);
		ajax_list();
		echo json_encode(array("status" => TRUE));
	}
  
	public function excel()
	{
		$this->load->library("Excel");

		$query = $this->Anggaran_pemasukan_model->data_excel("anggaran_pemasukan");
		$this->excel->export($query);
	}
	
	public function pdf()
	{
		$this->load->library("Chtml2pdf");
		$this->load->library("Header_file");
		
		$query = $this->Anggaran_pemasukan_model->data_pdf();
		$data['header'] = $this->header_file->pdf('100%');
		$data['query'] = $query;
		$content = $this->load->view('pdf_anggaran_pemasukan',$data,true);
		$this->chtml2pdf->cetak("P","A4",$content,"Anggaran_pemasukan","I"); 
	}

	public function pdf_buku_kas(){
		
		$this->load->library("fpdf");
		$query['saldo'] = $this->db->select('saldo')
		->where('month(tanggal_saldo)',date('m')-1)
		->get('saldo')->row_array();
		
		$query['jurnal'] = $this->db
		->select('
			jurnal.id,
			nama_anggaran,
			no_rekening,
			uraian,
			tanggal_jurnal,
			IF(tipe_jurnal="debit",jumlah_jurnal,0) AS pemasukan, 
			IF(tipe_jurnal="kredit",jumlah_jurnal,0) AS pengeluaran
			')
		->where('month(tanggal_jurnal)',date('m'))
		->join('anggaran','anggaran.id = jurnal.id_anggaran')
		->get('jurnal')->result_array();
		
		$this->load->view("pdf_buku_kas",$query);
	}
}
?>
