<?php  



/**

 * @author Achmad Solichin

 * @website http://achmatim.net

 * @email achmatim@gmail.com

 */


class FPDF_AutoWrapTable extends FPDF {

  	private $data = array();

  	private $options = array(

  		'filename' => '',

  		'destinationfile' => '',

  		'paper_size'=>'A4',

  		'orientation'=>'P'

  	);
	
	private $saldo = array();

  	function __construct($data = array(), $options = array(), $saldo = array()) {

    	parent::__construct();

    	$this->data = $data;

    	$this->options = $options;
	
	$this->saldo = $saldo;

	}

	

	public function rptDetailData () {

		//

		$border = 0;

		$this->AddPage();

		$this->SetAutoPageBreak(true,60);

		$this->AliasNbPages();

		$left = 25;

		

		//header

		$this->SetFont('Arial','B',16); 

		$this->MultiCell(0, 12, 'PEMERINTAHAN KABUPATEN GARUT',0,'C');

		$this->Ln(10);

		$this->MultiCell(0, 12, 'RUMAH SAKIT UMUM dr. SLAMET GARUT',0,'C');

		$this->Ln(10);

		$this->SetFont('Arial','',8); 

		$this->MultiCell(0, 12, 'Jalan Rumah Sakit No. 12 Garut Tlp.(0262)232720, Fax No. (0262)541372',0,'C');

		$this->Cell(0, 1, " ", "B");

		$this->Ln(10);

		$this->SetFont("", "B", 10);

		$this->SetX($left); $this->Cell(0, 10, 'BUKU KAS UMUM BLUD', 0, 1,'C');

		$this->Ln(10);

		
		$this->SetFont("", "", 8);

		$this->SetX($left+60); 
		$this->Cell(0, 10, 'SKPD',0,1,'L');
		$this->SetXY($left+300,$this->getY()-10);
		$this->Cell(0, 10, ': RSU dr SLAMET GARUT',0,1,'L');

		$this->Ln(5);

		$this->SetX($left+60); $this->Cell(0, 10, 'Pengguna Anggaran',0,1,'L');
		$this->SetXY($left+300,$this->getY()-10);
		$this->Cell(0, 10, ': Dr.H.Maskut Farid, MM',0,1,'L');

		$this->Ln(5);

		$this->SetX($left+60); $this->Cell(0, 10, 'Bendahara Pengeluran',0,1,'L');
		$this->SetXY($left+300,$this->getY()-10);
		$this->Cell(0, 10, ': Temmy Dewi Utami, SE',0,1,'L');

		$this->Ln(5);

		$this->SetX($left+60); $this->Cell(0, 10, 'Bulan',0,1,'L');
		$this->SetXY($left+300,$this->getY()-10);
		$this->Cell(0, 10, ': Juli 2016',0,1,'L');

		$this->Ln(10);

		

		$h = 13;

		$left = 40;

		$top = 80;	

		#tableheader

		$this->SetFillColor(255);

		$left = $this->GetX();
		$this->MultiCell(22, $h, 'No. Urut',1,0,'C');
		$this->SetXY($left += 22,$this->getY()-$h*2); $this->Cell(50, $h*2, 'Tanggal', 1, 0, 'C');
		$this->SetXY($left += 50,$this->getY()); $this->Cell(200, $h*2, 'Uraian', 1, 0, 'C');
		$this->SetXY($left += 200,$this->getY()); $this->Cell(90, $h*2, 'Kode Rekening', 1, 0, 'C');
		$this->SetXY($left += 90,$this->getY()); $this->MultiCell(60, $h, 'Penerimaan Rp.', 1, 0, 'C');
		$this->SetXY($left += 60,$this->getY()-$h*2); $this->MultiCell(60, $h, 'Pengeluaran Rp.', 1, 0, 'L');
		$this->SetXY($left += 60,$this->getY()-$h*2); $this->MultiCell(63, $h*2, 'Saldo Rp.', 1, 0, 'L');

		$left = $this->GetX();				
		$this->Cell(22,$h,'1',1,0,'C');
		$this->Cell(50,$h,'2',1,0,'C');
		$this->Cell(200,$h,'3',1,0,'C');
		$this->Cell(90,$h,'4',1,0,'C');
		$this->Cell(60,$h,'5',1,0,'C');
		$this->Cell(60,$h,'6',1,0,'C');
		$this->Cell(63,$h,'7',1,0,'C');
		$this->Ln($h);

		$this->SetFont('Arial','',9);

		$this->SetWidths(array(22,50,200,11.25,11.25,11.25,11.25,11.25,11.25,11.25,11.25,60,60,63));

		$this->SetAligns(array('C','C','L','C','C','C','C','C','C','C','C','R','R','R'));

		$no = 1;

		foreach ($this->data as $baris) {
			$no_rekening = explode('.',$baris['no_rekening']);
			$no1 = $no_rekening[0];
			$no2 = $no_rekening[1];
			$no3 = $no_rekening[2];
			$no4 = $no_rekening[3];
			$no5 = $no_rekening[4];
			$no6 = $no_rekening[5];
			$no7 = $no_rekening[6];
			$no8 = $no_rekening[7];

			$this->Row(

				array(
				$baris['id'], 
				convert_tgl($baris['tanggal_jurnal'],'d-M-y',1), 
				$baris['nama_anggaran'], 
				$no1, 
				$no2,
				$no3,
				$no4,
				$no5,
				$no6,
				$no7,
				$no8,
				($baris['pemasukan']!=0)?$baris['pemasukan']:'', 
				($baris['pengeluaran']!=0)?$baris['pengeluaran']:'', 
				$this->saldo['saldo']


			));

		}

			



	}



	public function printPDF () {

				

		if ($this->options['paper_size'] == "F4") {

			$a = 8.3 * 72; //1 inch = 72 pt

			$b = 13.0 * 72;

			$this->FPDF($this->options['orientation'], "pt", array($a,$b));

		} else {

			$this->FPDF($this->options['orientation'], "pt", $this->options['paper_size']);

		}

		

	    $this->SetAutoPageBreak(false);

	    $this->AliasNbPages();

	    $this->SetFont("helvetica", "B", 10);

	    //$this->AddPage();

	

	    $this->rptDetailData();

			    

	    $this->Output($this->options['filename'],$this->options['destinationfile']);

  	}

  	

  	

  	

  	private $widths;

	private $aligns;


	function SetWidths($w)

	{

		//Set the array of column widths

		$this->widths=$w;

	}



	function SetAligns($a)

	{

		//Set the array of column alignments

		$this->aligns=$a;

	}



	function Row($data)

	{

		//Calculate the height of the row

		$nb=0;

		for($i=0;$i<count($data);$i++)

			$nb=max($nb,$this->NbLines($this->widths[$i],$data[$i]));

		$h=10*$nb;

		//Issue a page break first if needed

		$this->CheckPageBreak($h);

		//Draw the cells of the row

		for($i=0;$i<count($data);$i++)

		{

			$w=$this->widths[$i];

			$a=isset($this->aligns[$i]) ? $this->aligns[$i] : 'L';

			//Save the current position

			$x=$this->GetX();

			$y=$this->GetY();

			//Draw the border

			$this->Rect($x,$y,$w,$h);

			//Print the text

			$this->MultiCell($w,10,$data[$i],0,$a);

			//Put the position to the right of the cell

			$this->SetXY($x+$w,$y);

		}

		//Go to the next line

		$this->Ln($h);

	}



	function CheckPageBreak($h)

	{

		//If the height h would cause an overflow, add a new page immediately

		if($this->GetY()+$h>$this->PageBreakTrigger)

			$this->AddPage($this->CurOrientation);

	}



	function NbLines($w,$txt)

	{

		//Computes the number of lines a MultiCell of width w will take

		$cw=&$this->CurrentFont['cw'];

		if($w==0)

			$w=$this->w-$this->rMargin-$this->x;

		$wmax=($w-2*$this->cMargin)*1000/$this->FontSize;

		$s=str_replace("\r",'',$txt);

		$nb=strlen($s);

		if($nb>0 and $s[$nb-1]=="\n")

			$nb--;

		$sep=-1;

		$i=0;

		$j=0;

		$l=0;

		$nl=1;

		while($i<$nb)

		{

			$c=$s[$i];

			if($c=="\n")

			{

				$i++;

				$sep=-1;

				$j=$i;

				$l=0;

				$nl++;

				continue;

			}

			if($c==' ')

				$sep=$i;

			$l+=$cw[$c];

			if($l>$wmax)

			{

				if($sep==-1)

				{

					if($i==$j)

						$i++;

				}

				else

					$i=$sep+1;

				$sep=-1;

				$j=$i;

				$l=0;

				$nl++;

			}

			else

				$i++;

		}

		return $nl;

	}

} //end of class


//pilihan

$options = array(

	'filename' => '', //nama file penyimpanan, kosongkan jika output ke browser

	'destinationfile' => 'I', //I=inline browser (default), F=local file, D=download

	'paper_size'=>'A4',	//paper size: F4, A3, A4, A5, Letter, Legal

	'orientation'=>'P' //orientation: P=portrait, L=landscape

);



$tabel = new FPDF_AutoWrapTable($jurnal, $options, $saldo);

$tabel->printPDF();

?>

