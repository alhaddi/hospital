<?php


class Welcomelib {
    public function test($string) {
        return str_replace('Hello','Hello !!',$string);
    }
}
