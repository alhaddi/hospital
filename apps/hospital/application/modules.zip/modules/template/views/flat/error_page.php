<div class="row">
	<div class="col-lg-12">
		<h1 class="page-header">Notifications</h1>
	</div>
	<!-- /.col-lg-12 -->
</div>
<div class="row">
	<div class="col-md-12">
		<div class="alert alert-danger">
			<b>Error Code <?=$err['error_code']?></b>
			<p><?=$err['error_desc']?></p> 
		</div>
	</div>
</div>