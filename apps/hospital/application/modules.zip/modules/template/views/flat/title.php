<div class="container-fluid">
	<div class="page-header">
		<div class="pull-left">
			<h1><?=$title?></h1>
		</div>
		<div class="pull-right">
			<ul class="stats">
				<li class="satgreen">
					<i class="fa fa-calendar"></i>
					<div class="details">
						<span class="big">100</span>
						<span>Antrian</span>
					</div>
				</li>
			</ul>
		</div>
	</div>
</div>