


<!-- Nice Scroll -->
<script src="<?=THEME_HOST?>plugins/nicescroll/jquery.nicescroll.min.js"></script>
<!-- jQuery UI -->
<script src="<?=THEME_HOST?>plugins/jquery-ui/jquery-ui.js"></script>
<!-- Touch enable for jquery UI -->
<script src="<?=THEME_HOST?>plugins/touch-punch/jquery.touch-punch.min.js"></script>
<!-- slimScroll -->
<script src="<?=THEME_HOST?>plugins/slimscroll/jquery.slimscroll.min.js"></script>
<!-- vmap -->
<script src="<?=THEME_HOST?>plugins/vmap/jquery.vmap.min.js"></script>
<script src="<?=THEME_HOST?>plugins/vmap/jquery.vmap.world.js"></script>
<script src="<?=THEME_HOST?>plugins/vmap/jquery.vmap.sampledata.js"></script>
<!-- Bootbox -->
<script src="<?=THEME_HOST?>plugins/bootbox/jquery.bootbox.js"></script>
<!-- Flot -->
<script src="<?=THEME_HOST?>plugins/flot/jquery.flot.min.js"></script>
<script src="<?=THEME_HOST?>plugins/flot/jquery.flot.bar.order.min.js"></script>
<script src="<?=THEME_HOST?>plugins/flot/jquery.flot.pie.min.js"></script>
<script src="<?=THEME_HOST?>plugins/flot/jquery.flot.resize.min.js"></script>
<!-- imagesLoaded -->
<script src="<?=THEME_HOST?>plugins/imagesLoaded/jquery.imagesloaded.min.js"></script>
<!-- PageGuide -->
<script src="<?=THEME_HOST?>plugins/pageguide/jquery.pageguide.js"></script>
<!-- FullCalendar -->
<script src="<?=THEME_HOST?>plugins/fullcalendar/moment.min.js"></script>
<script src="<?=THEME_HOST?>plugins/fullcalendar/fullcalendar.min.js"></script>
<!-- Chosen -->
<script src="<?=THEME_HOST?>plugins/chosen/chosen.jquery.min.js"></script>
<!-- select2 -->
<script src="<?=THEME_HOST?>plugins/select2/select2.min.js"></script>
<!-- icheck -->
<script src="<?=THEME_HOST?>plugins/icheck/jquery.icheck.min.js"></script>
<!-- Validation -->
<script src="<?=THEME_HOST?>plugins/validation/jquery.validate.min.js"></script>
<script src="<?=THEME_HOST?>plugins/validation/additional-methods.min.js"></script>
<!-- Bootbox -->
<script src="<?=THEME_HOST?>plugins/bootbox/jquery.bootbox.js"></script>
<!-- New DataTables -->
<script src="<?=THEME_HOST?>plugins/momentjs/jquery.moment.min.js"></script>
<script src="<?=THEME_HOST?>plugins/momentjs/moment-range.min.js"></script>
<script src="<?=THEME_HOST?>plugins/datatables/js/jquery.dataTables.min.js"></script>
<script src="<?=THEME_HOST?>plugins/datatables/js/dataTables.bootstrap.min.js"></script>
<script src="<?=THEME_HOST?>plugins/datatables/extensions/dataTables.tableTools.min.js"></script>
<script src="<?=THEME_HOST?>plugins/datatables/extensions/dataTables.colReorder.min.js"></script>
<script src="<?=THEME_HOST?>plugins/datatables/extensions/dataTables.colVis.min.js"></script>
<script src="<?=THEME_HOST?>plugins/datatables/extensions/dataTables.scroller.min.js"></script>
<script src="<?=THEME_HOST?>plugins/datatables/js/dataTables.date_range.js"></script>
<!-- SweetAlert 2 -->
<script src="<?=THEME_HOST?>plugins/sweetalert2/sweetalert2.min.js"></script>
<!--DatePicker-->
<script src="<?=THEME_HOST?>plugins/datetimepicker/js/jquery.datetimepicker.full.min.js"></script>
<!--maskMoney-->
<script type="text/ecmascript" src="<?=THEME_HOST?>plugins/maskmoney/jquery.maskMoney.js"></script>
<!-- XEditable -->
<script src="<?=THEME_HOST?>plugins/momentjs/jquery.moment.js"></script>
<script src="<?=THEME_HOST?>plugins/mockjax/jquery.mockjax.js"></script>
<script src="<?=THEME_HOST?>plugins/xeditable/bootstrap-editable.min.js"></script>
<script src="<?=THEME_HOST?>plugins/xeditable/demo.js"></script>
<script src="<?=THEME_HOST?>plugins/xeditable/address.js"></script>


<!-- Theme framework -->
<script src="<?=THEME_HOST?>js/eakroko.min.js"></script>
<!-- Theme scripts -->
<script src="<?=THEME_HOST?>js/application.min.js"></script>
<!-- Just for demonstration -->
<script src="<?=THEME_HOST?>js/demonstration.min.js"></script>
<!-- Main framework -->
<script src="<?=THEME_HOST?>js/main.js"></script>
	