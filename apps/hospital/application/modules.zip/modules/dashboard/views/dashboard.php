
<div class="container-fluid">
	<div class="row">
		<div class="col-sm-12">
			<div class="box">
				<div class="box-title">
					<h3>
						<i class="fa fa-dashboard"></i>
						<?=$title?>
					</h3>
				</div>
				<div class="box-content">
					<ul class="tiles tiles-center nomargin">						
						<?php foreach($menu as $row){ ?>
							<li>
								<a href="<?=site_url($row->link)?>">
									<img src="<?=FILES_HOST?>/img/menu/<?=$row->icon?>.png">
								</a>
								<span><?=$row->nama?></span>
							</li>						
						<?php } ?>
					</ul>
				</div>
			</div>
		</div>
	</div>
</div>

<?php
	$a = get_wilayah('100100');
	//var_dump($a->Kota);
?>
<!--select class="wilayah" id="Kota" name="Kota" style="width:83%" >
	
</select>

<script>
$('.wilayah').select2({
		ajax: {
			url: '<?=site_url('dashboard/json_wilayah')?>',
			dataType: 'json',
			delay: 250,
			data: function (params) {
				return {
					q: params.term, // search term
					page: params.page,
					group: '02',
					kode: '0',
					identitas: 'identitas',
				};
			},
			processResults: function (data,params) {
				params.page = params.page || 1;
				return {
					results: data.items,
					//pagination: {
					//	more: (params.page * 30) < data.total_count
					//}
				};
			},
			cache: true
		}
		
	});	
</script-->