

<?php

defined("BASEPATH") OR exit("No direct script access allowed");



class Reports extends MY_Model {



	var $table1;

	var $table2;

	var $column_order1;

	var $column_order2;

	var $column_search1;


	var $column_search4;
	var $column_search6;

	var $column_excel5;
	var $column_excel6;

	var $column_pdf4;
	var $column_pdf6;

	var $column_order4;
	var $column_order6;

	var $order1;

	var $order2;

	

	public function __construct()

	{

		parent::__construct();

		$this->load->database();

	}

	

	public function initialize($config){

		

		$this->table1 = $config["table1"];

		$this->table2 = $config["table2"];

		$this->column_order1 = $config["column_order1"]; //set column field database for datatable orderable

		$this->column_order2 = $config["column_order2"]; //set column field database for datatable orderable

		$this->column_order3 = $config["column_order3"]; //set column field database for datatable orderable

		$this->column_order4 = $config["column_order4"]; //set column field database for datatable orderable

		$this->column_search1 = $config["column_search1"]; //set column field database for datatable searchable just firstname , lastname , address are searchable

		$this->column_search2 = $config["column_search2"]; //set column field database for datatable searchable just firstname , lastname , address are searchable

		$this->column_search3 = $config["column_search3"]; //set column field database for datatable searchable just firstname , lastname , address are searchable

		$this->column_search4 = $config["column_search4"]; //set column field database for datatable searchable just firstname , lastname , address are searchable

		$this->column_search6 = $config["column_search4"]; //set column field database for datatable searchable just firstname , lastname , address are searchable

		$this->column_excel1 = $config["column_excel1"]; //set column field database for datatable searchable just firstname , lastname , address are searchable

		$this->column_excel2 = $config["column_excel2"]; //set column field database for datatable searchable just firstname , lastname , address are searchable

		$this->column_excel3 = $config["column_excel3"]; //set column field database for datatable searchable just firstname , lastname , address are searchable

		$this->column_excel4 = $config["column_excel4"]; //set column field database for datatable searchable just firstname , lastname , address are searchable
		$this->column_excel6 = $config["column_excel4"]; //set column field database for datatable searchable just firstname , lastname , address are searchable

		$this->column_pdf1 = $config["column_pdf1"]; //set column field database for datatable searchable just firstname , lastname , address are searchable

		$this->column_pdf2 = $config["column_pdf2"]; //set column field database for datatable searchable just firstname , lastname , address are searchable

		$this->column_pdf3 = $config["column_pdf3"]; //set column field database for datatable searchable just firstname , lastname , address are searchable

		$this->column_pdf4 = $config["column_pdf4"]; //set column field database for datatable searchable just firstname , lastname , address are searchable
		$this->column_pdf6 = $config["column_pdf4"]; //set column field database for datatable searchable just firstname , lastname , address are searchable

		$this->order1 = $config["order1"]; // default order 

		$this->order2 = $config["order2"]; // default order 

	}

	

	private function _get_datatables_query($p)

	{

		switch($p)

		{

			case '1' : 

				$this->db->from($this->table1); 

				$order = $this->order1;

				$column_excel = $this->column_excel1;

				$column_pdf = $this->column_pdf1;

				$column_search = $this->column_search1;

				$column_order = $this->column_order1;

				break;

			case '2' : 

				$this->db->from($this->table1); 

				$order = $this->order1;

				$column_excel = $this->column_excel2;

				$column_pdf = $this->column_pdf2;

				$column_search = $this->column_search2;

				$column_order = $this->column_order2;

				break;				

			case '3' : 
				
				$column_excel = $this->column_excel3;

				$column_pdf = $this->column_pdf3;

				$column_search = $this->column_search3;

				$this->db->from($this->table2); 
				break;

			case '4' : 
				$column_excel = $this->column_excel4;

				$column_pdf = $this->column_pdf4;

				$column_search = $this->column_search4;

				$this->db->from($this->table2); 

				break;

			case '5' : 

				$this->db->from($this->table2); 

				$order = $this->order2;

				$column_excel = $this->column_excel6;

				$column_pdf = $this->column_pdf6;

				$column_search = $this->column_search6;

				$column_order = $this->column_order6;

				break;

		}
		

		$i = 0;

	

		foreach ($column_search as $item) // loop column 

		{

			if($_POST["search"]["value"]) // if datatable send POST for search

			{

				

				if($i===0) // first loop

				{

					$this->db->group_start(); // open bracket. query Where with OR clause better with bracket. because maybe can combine with other WHERE with AND.

					$this->db->like($item, $_POST["search"]["value"]);

				}

				else

				{

					$this->db->or_like($item, $_POST["search"]["value"]);

				}



				if(count($column_search) - 1 == $i) //last loop

					$this->db->group_end(); //close bracket

			}

			$i++;

		}

		

		if(isset($_POST["order"])) // here order processing

		{

			$this->db->order_by($this->column_order[$_POST["order"]["0"]["column"]], $_POST["order"]["0"]["dir"]);

		} 

		else if(isset($order))

		{

			$this->db->order_by(key($order), $order[key($order)]);

		}

	}



	function get_datatables($p)

	{

		$this->_get_datatables_query($p);
		
		$date_filter = array(
			1=>'ms_pasien',
			2=>'trs_appointment',
			3=>'trs_billing'
		);
		
		
		if(!empty($_POST['custom_filter']) && !empty($date_filter[$p]))
		{
			$custom_filter = $_POST['custom_filter'];
			
			if(count($custom_filter)>0)
			{
				foreach($custom_filter as $cf){
					foreach($cf  as $index=>$value){
						if($index == 'datatable_daterange1')
						{
							$date1 = $value;
						}
						elseif($index == 'datatable_daterange2')
						{
							$date2 = $value;
						}
						else
						{
							$where_filter[$index] = $value;
						}
					}
					
					if(!empty($date1) && !empty($date2))
					{
						$this->db->where('DATE('.$date_filter[$p].'.add_time) >=',convert_tgl($date1,'Y-m-d'));
						$this->db->where('DATE('.$date_filter[$p].'.add_time) <=',convert_tgl($date2,'Y-m-d'));
					}
				}
				if(!empty($where_filter))
				{
					$where_filter = array_filter($where_filter);
					$this->db->group_start(); // open bracket. query Where with OR clause better with bracket. because maybe can combine with other WHERE with AND.
						$this->db->where($where_filter);
					$this->db->group_end(); //close bracket
				}
			}
		}
		
		if($_POST["length"] != -1)

		{

			$this->db->limit($_POST["length"], $_POST["start"]);

		}

		switch($p){

			case '1' : 
				
				$query = $this->db->select('
				ms_pasien.rm,
				ms_pasien.no_identitas,
				ms_pasien.nama_lengkap,
				ms_cara_bayar.nama as cara_bayar,
				ms_pasien.jk,
				ms_pasien.usia,
				ms_pasien.hp,
				ms_pasien.alamat,
				ms_poliklinik.nama as poliklinik,
				ms_pasien.add_time as tgl_bergabung')
				->group_by('ms_pasien.id')
				->join('trs_appointment','trs_appointment.id_pasien = ms_pasien.id')
				->join('ms_cara_bayar','trs_appointment.id_cara_bayar = ms_cara_bayar.id')
				->join('ms_poliklinik','trs_appointment.id_poliklinik = ms_poliklinik.id')
				->get();
				break;
			
			case '2' : 
			$query = $this->db->select('
				ms_pasien.rm,
				ms_pasien.no_identitas,
				ms_pasien.nama_lengkap,
				ms_cara_bayar.nama as cara_bayar,
				ms_komponen_registrasi.nama as nama_pembayaran,
				trs_billing.total_bayar,
				trs_billing.last_update as tgl_datang,
				trs_billing.keterangan')
				->join('trs_appointment','trs_appointment.id_pasien = ms_pasien.id')
				->join('ms_cara_bayar','trs_appointment.id_cara_bayar = ms_cara_bayar.id')
				->join('trs_billing','trs_appointment.id = trs_billing.id_appointment')
				->join('ms_komponen_registrasi','ms_komponen_registrasi.id = trs_billing.id_komponen')
				->get();
				break;
			case '3' : 
				$query = $this->db->select('
					ms_poliklinik.nama as poliklinik,
					IFNULL(COUNT(trs_billing.id),0) as jml_pasien,
					IFNULL(SUM(trs_billing.nominal),0) as total
				',false)
				->group_by('ms_poliklinik.id')
				->join('trs_appointment','trs_appointment.id_poliklinik = ms_poliklinik.id','left')
				->join('trs_billing','trs_billing.id_appointment = trs_appointment.id AND trs_billing.id_komponen IN (1,2)','left')
				->get();
				break;
			case '4' :
				$query = $this->db->select('
					ms_poliklinik.nama as poliklinik,
					IFNULL(COUNT(trs_billing.id),0) as jml_pasien,
					IFNULL(SUM(trs_billing.nominal),0) as total
				',false)
				->group_by('ms_poliklinik.id')
				->join('trs_appointment','trs_appointment.id_poliklinik = ms_poliklinik.id','left')
				->join('trs_billing','trs_billing.id_appointment = trs_appointment.id AND trs_billing.id_komponen IN (3)','left')
				->get();
				break;
			case '5' :
				$query = $this->db->select('
					ms_poliklinik.nama as poliklinik,
					IFNULL(COUNT(trs_billing.id),0) as jml_pasien,
					IFNULL(SUM(trs_billing.nominal),0) as total
				',false)
				->group_by('ms_poliklinik.id')
				->join('trs_appointment','trs_appointment.id_poliklinik = ms_poliklinik.id','left')
				->join('trs_billing','trs_billing.id_appointment = trs_appointment.id AND trs_billing.id_komponen IN (4)','left')
				->get();
				break;
			

		}

		

		return $query->result();

	}



	function count_filtered($p)

	{

		$this->_get_datatables_query($p);

		switch($p){

			case '1' : $query = $this->db->select('ms_pasien.id')
			->join('trs_appointment','trs_appointment.id_pasien = ms_pasien.id')
			->join('ms_cara_bayar','trs_appointment.id_cara_bayar = ms_cara_bayar.id')
			->join('ms_poliklinik','trs_appointment.id_poliklinik = ms_poliklinik.id')
			->get();

			break;
			
			case '2' : $query = $this->db->select('ms_pasien.id')
			->join('trs_appointment','trs_appointment.id_pasien = ms_pasien.id')
			->join('ms_cara_bayar','trs_appointment.id_cara_bayar = ms_cara_bayar.id')
			->join('trs_billing','trs_appointment.id = trs_billing.id_appointment')
			->get();
			break;
	
			case '3' : 
			case '4' :
			case '5' : $query = $this->db->select('ms_poliklinik.id')->get();
			break;

		}

		return $query->num_rows();

	}



	public function count_all($p)

	{

		switch($p)

		{

			case '1' : 
			case '2' : $this->db->from($this->table1); break;
			case '3' : 
			case '4' : 
			case '5' : $this->db->from($this->table2); break;

		}

		return $this->db->count_all_results();

	}

	

		

	public function list_fields($list_fields){

		$this->db->select(implode(",",$list_fields));

		$this->db->limit(1,0);

		

		$query = $this->db->get($this->table1);

		return $query->field_data();

	}

	

	public function data_excel($field="",$p){

		switch($p)

		{

			case '1' : 

				$this->db->select('
				ms_pasien.rm,
				ms_pasien.no_identitas,
				ms_pasien.nama_lengkap,
				ms_cara_bayar.nama as cara_bayar,
				ms_pasien.jk,
				ms_pasien.usia,
				ms_pasien.hp,
				ms_pasien.alamat,
				ms_poliklinik.nama as poliklinik,
				ms_pasien.add_time as tgl_bergabung')
				->from($this->table1)
				->join('trs_appointment','trs_appointment.id_pasien = ms_pasien.id')
				->join('ms_cara_bayar','trs_appointment.id_cara_bayar = ms_cara_bayar.id')
				->join('ms_poliklinik','trs_appointment.id_poliklinik = ms_poliklinik.id'); 
				$column_excel = $this->column_excel1;
				break;

			case '2' : 

				$query = $this->db->select('
				ms_pasien.rm,
				ms_pasien.no_identitas,
				ms_pasien.nama_lengkap,
				ms_cara_bayar.nama as cara_bayar,
				ms_komponen_registrasi.nama as nama_pembayaran,
				trs_billing.total_bayar,
				trs_billing.last_update as tgl_datang,
				trs_billing.keterangan')
				->from($this->table1)
				->join('trs_appointment','trs_appointment.id_pasien = ms_pasien.id')
				->join('ms_cara_bayar','trs_appointment.id_cara_bayar = ms_cara_bayar.id')
				->join('trs_billing','trs_appointment.id = trs_billing.id_appointment')
				->join('ms_komponen_registrasi','ms_komponen_registrasi.id = trs_billing.id_komponen');

				$column_excel = $this->column_excel3;

				break;				

			case '3' : 
				$this->db->select('
					ms_poliklinik.nama as poliklinik,
					IFNULL(COUNT(trs_billing.id),0) as jml_pasien,
					IFNULL(SUM(trs_billing.nominal),0) as total
				',false)
				->from($this->table2)
				->group_by('ms_poliklinik.id')
				->join('trs_appointment','trs_appointment.id_poliklinik = ms_poliklinik.id','left')
				->join('trs_billing','trs_billing.id_appointment = trs_appointment.id AND trs_billing.id_komponen IN (1,2)','left');
				
				$column_excel = $this->column_excel4;
				break;
			
			case '4' : 
				$this->db->select('
					ms_poliklinik.nama as poliklinik,
					IFNULL(COUNT(trs_billing.id),0) as jml_pasien,
					IFNULL(SUM(trs_billing.nominal),0) as total
				',false)
				->from($this->table2)
				->group_by('ms_poliklinik.id')
				->join('trs_appointment','trs_appointment.id_poliklinik = ms_poliklinik.id','left')
				->join('trs_billing','trs_billing.id_appointment = trs_appointment.id AND trs_billing.id_komponen IN (3)','left');
				
				$column_excel = $this->column_excel4;
				break;

			case '5' :
				$this->db->select('
					ms_poliklinik.nama as poliklinik,
					IFNULL(COUNT(trs_billing.id),0) as jml_pasien,
					IFNULL(SUM(trs_billing.nominal),0) as total
				',false)
				->group_by('ms_poliklinik.id')
				->from($this->table2)
				->join('trs_appointment','trs_appointment.id_poliklinik = ms_poliklinik.id','left')
				->join('trs_billing','trs_billing.id_appointment = trs_appointment.id AND trs_billing.id_komponen IN (4)','left');
		}

		$field = (!empty($field))?$field:$column_excel;

		$query = $this->db->get();

		return $query->result_array();

	}

	

	public function data_pdf($p){

		switch($p)

		{

			case '1' : 

				$this->db->select('
				ms_pasien.rm,
				ms_pasien.no_identitas,
				ms_pasien.nama_lengkap,
				ms_cara_bayar.nama as cara_bayar,
				ms_pasien.jk,
				ms_pasien.usia,
				ms_pasien.hp,
				ms_pasien.alamat,
				ms_poliklinik.nama as poliklinik,
				ms_pasien.add_time as tgl_bergabung')
				->from($this->table1)
				->join('trs_appointment','trs_appointment.id_pasien = ms_pasien.id')
				->join('ms_cara_bayar','trs_appointment.id_cara_bayar = ms_cara_bayar.id')
				->join('ms_poliklinik','trs_appointment.id_poliklinik = ms_poliklinik.id'); 
				$column_pdf = $this->column_pdf1;
				break;

			case '2' : 

				$this->db->select('
				ms_pasien.rm,
				ms_pasien.no_identitas,
				ms_pasien.nama_lengkap,
				ms_cara_bayar.nama as cara_bayar,
				ms_komponen_registrasi.nama as nama_pembayaran,
				trs_billing.total_bayar,
				trs_billing.last_update as tgl_datang,
				trs_billing.keterangan')
				->from($this->table1)
				->join('trs_appointment','trs_appointment.id_pasien = ms_pasien.id')
				->join('ms_cara_bayar','trs_appointment.id_cara_bayar = ms_cara_bayar.id')
				->join('trs_billing','trs_appointment.id = trs_billing.id_appointment')
				->join('ms_komponen_registrasi','ms_komponen_registrasi.id = trs_billing.id_komponen');
				$column_pdf = $this->column_pdf3;

				break;				

			case '3' : 
				$this->db->select('
					ms_poliklinik.nama as poliklinik,
					IFNULL(COUNT(trs_billing.id),0) as jml_pasien,
					IFNULL(SUM(trs_billing.nominal),0) as total
				',false)
				->group_by('ms_poliklinik.id')
				->from($this->table2)
				->join('trs_appointment','trs_appointment.id_poliklinik = ms_poliklinik.id','left')
				->join('trs_billing','trs_billing.id_appointment = trs_appointment.id AND trs_billing.id_komponen IN (1,2)','left');
				
				$column_pdf = $this->column_pdf4;
				break;

			case '4' : 
				$this->db->select('
					ms_poliklinik.nama as poliklinik,
					IFNULL(COUNT(trs_billing.id),0) as jml_pasien,
					IFNULL(SUM(trs_billing.nominal),0) as total
				',false)
				->group_by('ms_poliklinik.id')
				->from($this->table2)
				->join('trs_appointment','trs_appointment.id_poliklinik = ms_poliklinik.id','left')
				->join('trs_billing','trs_billing.id_appointment = trs_appointment.id AND trs_billing.id_komponen IN (3)','left');
				
				$column_pdf = $this->column_pdf4;
				break;

			case '5' :
				$this->db->select('
					ms_poliklinik.nama as poliklinik,
					IFNULL(COUNT(trs_billing.id),0) as jml_pasien,
					IFNULL(SUM(trs_billing.nominal),0) as total
				',false)
				->group_by('ms_poliklinik.id')
				->from($this->table2)
				->join('trs_appointment','trs_appointment.id_poliklinik = ms_poliklinik.id','left')
				->join('trs_billing','trs_billing.id_appointment = trs_appointment.id AND trs_billing.id_komponen IN (4)','left');

		}

		$field = (!empty($field))?$field:$column_pdf;

		$query = $this->db->get();

		return $query->result_array();

	}

	

}



