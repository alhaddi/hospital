<button onclick="location.href='<?=site_url('report/excel/2')?>'" class="btn btn-xs btn-success"><span class="fa fa-file"></span> &nbsp; Excel File </button>
<button onclick="location.href='<?=site_url('report/showPembayaran')?>'" class="btn btn-xs btn-success"><span class="fa fa-print"></span> &nbsp; Pdf File </button>
<table id="<?=$id_table2?>" class="table table-hover table-nomargin table-striped table-bordered" 
data-plugin="datatable-server-side" 
data-datatable-list="<?=$datatable_list2?>"
data-datatable-colvis="true"
data-datatable-daterange="true"
data-datatable-nocolvis=""
>
	<thead>
		<tr>
			<th data-datatable-align="text-center">No.Rm</th>
			<th data-datatable-align="text-center">Identitas</th>
			<th data-datatable-align="text-left">Nama</th>
			<th data-datatable-align="text-center">Cara Bayar</th>
			<th data-datatable-align="text-left">Nama Bayar</th>
			<th data-datatable-align="text-right">Nominal</th>
			<th data-datatable-align="text-center">Tgl. Bayar</th>
			<th data-datatable-align="text-left">Keterangan</th>
		</tr>
	</thead>
	<tbody>
	</tbody>
	
	<tfoot>
		<tr>
			<th colspan="5" style="text-align:right;">Total</th>
			<th><?=rupiah($total_pembayaran->total)?></th>
			<th colspan="2"></th>
		</tr>
	</tfoot>
</table>