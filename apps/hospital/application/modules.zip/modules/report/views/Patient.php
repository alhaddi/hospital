<button onclick="location.href='<?=site_url('report/excel/1')?>'" class="btn btn-xs btn-success"><span class="fa fa-file"></span> &nbsp; Excel File </button>
<button onclick="location.href='<?=site_url('report/showPasien')?>'" class="btn btn-xs btn-success"><span class="fa fa-print"></span> &nbsp; Pdf File </button>
<table id="<?=$id_table1?>" class="table table-hover table-nomargin table-striped table-bordered" 
data-plugin="datatable-server-side" 
data-datatable-list="<?=$datatable_list1?>"
data-datatable-colvis="true"
data-datatable-daterange="true"
data-datatable-nocolvis=""
>
	<thead>
		<tr>
            <th data-datatable-align="text-center">No.Rm</th>
            <th data-datatable-align="text-center">Identitas</th>
            <th data-datatable-align="text-left">Nama</th>
            <th data-datatable-align="text-center">Cara Bayar</th>
            <th data-datatable-align="text-center">L/P</th>
            <th data-datatable-align="text-center">Umur</th>
            <th data-datatable-align="text-center">No Kontak</th>
            <th data-datatable-align="text-left">Alamat</th>
            <th data-datatable-align="text-left">Poliklinik</th>
            <th data-datatable-align="text-center">Tgl. Bergabung</th>
		</tr>
	</thead>
	<tbody>
	</tbody>
</table>