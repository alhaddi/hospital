            <button onclick="location.href='<?=site_url('report/excel/4')?>'" class="btn btn-xs btn-success"><span class="fa fa-file"></span> &nbsp; Excel File </button>
            <button onclick="location.href='<?=site_url('report/showInternalKonsultasi')?>'" class="btn btn-xs btn-success"><span class="fa fa-print"></span> &nbsp; Pdf File </button>
<table id="<?=$id_table4?>" class="table table-hover table-nomargin table-striped table-bordered" 
data-plugin="datatable-server-side" 
data-datatable-list="<?=$datatable_list4?>"
data-datatable-colvis="true"
data-datatable-nocolvis=""
>
	<thead>
    <tr>
        <th data-datatable-align="text-center" width="50">No</th>
        <th data-datatable-align="text-left">Klinik</th>
        <th data-datatable-align="text-left">Referensi</th>
        <th data-datatable-align="text-center">Jml pasien</th>
        <th data-datatable-align="text-right">jasa rumah sakit</th>
        <th data-datatable-align="text-right">jasa Medis</th>
        <th data-datatable-align="text-right">Total</th>
    </tr>
    </thead>
	<tbody>
	</tbody>
	<tfoot>
		<tr>
			<th colspan="3" style="text-align:right;">Total</th>
			<th><?=$setoran_internal_konsultasi->jml_pasien?></th>
			<th></th>
			<th><?=rupiah($setoran_internal_konsultasi->total)?></th>
			<th><?=rupiah($setoran_internal_konsultasi->total)?></th>
		</tr>
	</tfoot>
</table>