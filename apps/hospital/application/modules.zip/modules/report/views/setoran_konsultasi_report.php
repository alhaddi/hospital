<?php







/**



     * APLICATION INFO  : PDF Report with FPDF 1.6



     * DATE CREATED     : 21 juni 2013



	 * DEVELOPED BY     : Radi Ganteng 



	 */







/* setting zona waktu */ 



//date_default_timezone_set('Asia/Jakarta');







/* konstruktor halaman pdf sbb :    



   P  = Orientasinya "Potrait"



   cm = ukuran halaman dalam satuan centimeter



   A4 = Format Halaman



   



   jika ingin mensetting sendiri format halamannya, gunakan array(width, height)  



   contoh : $this->fpdf->FPDF("P","cm", array(20, 20));  



*/







$this->fpdf = new fpdf();







//$this->fpdf->FPDF("P","cm","Legal");



$this->fpdf->FPDF('P','cm',"A4");







// kita set marginnya dimulai dari kiri, atas, kanan. jika tidak diset, defaultnya 1 cm



$this->fpdf->SetMargins(0,0.5,0.5,0);



$this->fpdf->SetAutoPageBreak(false);







/* AliasNbPages() merupakan fungsi untuk menampilkan total halaman



   di footer, nanti kita akan membuat page number dengan format : number page / total page



*/



$this->fpdf->AliasNbPages();







// AddPage merupakan fungsi untuk membuat halaman baru



$this->fpdf->AddPage();







$this->fpdf->SetFont('Arial','',8); 



$this->fpdf->setXY(0.5,3);



$this->fpdf->Cell(5.5,2,'HARI/TANGGAL : ',0,0,'C');







$namahari = date('l');



$namabulan = date('n');



  



  if ($namahari == "Sunday") $namahari2 = "Minggu"; 



  else if ($namahari == "Monday") $namahari2 = "Senin"; 



  else if ($namahari == "Tuesday") $namahari2 = "Selasa"; 



  else if ($namahari == "Wednesday") $namahari2 = "Rabu"; 



  else if ($namahari == "Thursday") $namahari2 = "Kamis"; 



  else if ($namahari == "Friday") $namahari2 = "Jumat"; 



  else if ($namahari == "Saturday") $namahari2 = "Sabtu";







  switch ($namabulan) {



    case '1':



    $namabulan2 = "Januari";



    break;



    case '2':



    $namabulan2 = "Februari";



    break;



    case '3':



    $namabulan2 = "Maret";



    break;



    case '4':



    $namabulan2 = "April";



    break;



    case '5':



    $namabulan2 = "Mei";



    break;



    case '6':



    $namabulan2 = "Juni";



    break;



    case '7':



    $namabulan2 = "Juli";



    break;



    case '8':



    $namabulan2 = "Agustus";



    break;



    case '9':



    $namabulan2 = "September";



    break;



    case '10':



    $namabulan2 = "Oktober";



    break;



    case '11':



    $namabulan2 = "November";



    break;



    case '12':



    $namabulan2 = "Desember";



    break;



    



    default:



      break;



  }







$this->fpdf->SetFont('Arial','',8); 



$this->fpdf->setXY(3.7,3);



$this->fpdf->Cell(5.5,2,$namahari2.', '.date('d').' '.$namabulan2.' '.date('Y'),0,0,'C');







$this->fpdf->SetFont('Arial','B',8); 



$this->fpdf->setXY(1,4.5);



$this->fpdf->Cell(0.7,1,'NO',1,0,'C');



$this->fpdf->Cell(3.5,1,'POLIKLINIK',1,0,'C');



$this->fpdf->Cell(3,1,'NOMOR STROOK',1,0,'C');



$this->fpdf->Cell(3,1,'JUMLAH PASIEN',1,0,'C');



$this->fpdf->Cell(3.5,1,'JASA RUMAH SAKIT',1,0,'C');



$this->fpdf->Cell(2.5,1,'JASA MEDIS',1,0,'C');



$this->fpdf->Cell(3,1,'TOTAL',1,0,'C');







$x = 0;



$y = 5.5;



$jmlpasien = 0;



$jasa1 = 0;



$jasa2 = 0;



foreach ($polikliniks as $pl) {



  if(($x+1) % 21 == 0){



      $this->fpdf->AddPage();







      $this->fpdf->SetFont('Arial','',8); 



      $this->fpdf->setXY(0.5,3);



      $this->fpdf->Cell(5.5,2,'HARI/TANGGAL : ',0,0,'C');







      $this->fpdf->setXY(3.7,3);



      $this->fpdf->Cell(5.5,2,$namahari2.', '.date('d').' '.$namabulan2.' '.date('Y'),0,0,'C');







      $this->fpdf->SetFont('Arial','B',8); 



      $this->fpdf->setXY(1,4.5);



      $this->fpdf->Cell(0.7,1,'NO',1,0,'C');



      $this->fpdf->Cell(3.5,1,'POLIKLINIK',1,0,'C');



      $this->fpdf->Cell(3,1,'NOMOR STROOK',1,0,'C');



      $this->fpdf->Cell(3,1,'JUMLAH PASIEN',1,0,'C');



      $this->fpdf->Cell(3.5,1,'JASA RUMAH SAKIT',1,0,'C');



      $this->fpdf->Cell(2.5,1,'JASA MEDIS',1,0,'C');



      $this->fpdf->Cell(3,1,'TOTAL',1,0,'C');







      $x = 0;



  }



  $this->fpdf->SetFont('Arial','',8); 



  $this->fpdf->setXY(1,$y+($x*1));



  $this->fpdf->Cell(0.7,1,$x+1,1,0,'C');



  $this->fpdf->Cell(3.5,1,$pl['poliklinik'],1,0,'C');



  $this->fpdf->Cell(3,1,'',1,0,'C');





  $this->fpdf->Cell(3,1,(isset($pl['jml_pasien']))? $pl['jml_pasien'] : '',1,0,'C');



  $this->fpdf->Cell(3.5,1,(isset($pl['jml_pasien']))? rupiah($pl['total']*(60/100)) : '',1,0,'C');



  $this->fpdf->Cell(2.5,1,(isset($pl['jml_pasien']))? rupiah($pl['total']*(40/100)) : '',1,0,'C');



  $this->fpdf->Cell(3,1,(isset($pl['jml_pasien']))? rupiah($pl['total']) : '',1,0,'C');



  $jasa1 += $pl['total']*(60/100);



  $jasa2 += $pl['total']*(40/100);



  $jmlpasien += $pl['jml_pasien'];



  $x++;



}



  $this->fpdf->setXY(1,$y+($x*1));



  $this->fpdf->Cell(0.7,1,'',1,0,'C');



  $this->fpdf->Cell(3.5,1,'JUMLAH',1,0,'C');



  $this->fpdf->Cell(3,1,'',1,0,'C');



  $this->fpdf->Cell(3,1,(isset($jmlpasien))? $jmlpasien : '',1,0,'C');



  $this->fpdf->Cell(3.5,1,(isset($jasa1))? rupiah($jasa1) : '',1,0,'C');



  $this->fpdf->Cell(2.5,1,(isset($jasa2))? rupiah($jasa2) : '',1,0,'C');



  $this->fpdf->Cell(3,1,(isset($jasa1))? rupiah($jasa1+$jasa2) : '',1,0,'C');









  $this->fpdf->setXY(1,$y+2+($x*1));



  $this->fpdf->Cell(6,2,'',1,0,'C');



  $this->fpdf->Cell(13.2,2,'Garut,...............................................................',1,0,'C');







  $this->fpdf->setXY(7,$y+2.5+($x*1));



  $this->fpdf->Cell(13.5,2,$this->session->userdata("username"),0,0,'C');





    $this->fpdf->Output("setoran_loket.pdf","I");





?>



