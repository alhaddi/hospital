<div class="container-fluid">
	<div class="row">
		<div class="col-sm-12">
			<div class="box box-bordered box-color">
				<div class="box-title">
					<h3>
						<i class="fa fa-table"></i>
						MIS Report
					</h3>
					
				</div>
				<div class="box-content nopadding">
					<div class="row">
						<div class="col-sm-12">
							<ul class="nav nav-tabs">
								<li class="active"><a href="#Patient" data-toggle="tab" aria-expanded="true">Patient</a></li>
								
								<li class=""><a href="#TotalPembayaran" data-toggle="tab" aria-expanded="false">Total Pembayaran</a></li>
								
								<li class=""><a href="#SetoranRegistrasi" data-toggle="tab" aria-expanded="false">Setoran Registrasi</a></li>
								
								<li class=""><a href="#SetoranInternalKonsultasi" data-toggle="tab" aria-expanded="false">Setoran Internal Konsultasi</a></li>
								
								<li class=""><a href="#SetoranKonsultasi" data-toggle="tab" aria-expanded="false">Setoran Konsultasi</a></li>
							</ul>
							<div class="tab-content nopadding">
								<div class="tab-pane active" id="Patient">
									<?=$this->load->view("report/Patient",$data)?>
								</div>
								<div class="tab-pane" id="TotalPembayaran">
									<?=$this->load->view("report/TotalPembayaran",$data)?>
								</div>
								<div class="tab-pane" id="SetoranRegistrasi">
									<?=$this->load->view("report/SetoranRegistrasi",$data)?>
								</div>
								<div class="tab-pane" id="SetoranInternalKonsultasi">
									<?=$this->load->view("report/SetoranInternalKonsultasi",$data)?>
								</div>
								<div class="tab-pane" id="SetoranKonsultasi">
									<?=$this->load->view("report/SetoranKonsultasi",$data)?>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
